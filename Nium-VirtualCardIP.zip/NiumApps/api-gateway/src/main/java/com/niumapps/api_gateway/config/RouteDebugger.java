package com.niumapps.api_gateway.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.cloud.gateway.route.RouteDefinitionLocator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RouteDebugger {

    @Bean
    CommandLineRunner routePrinter(RouteDefinitionLocator locator) {
        return args -> locator.getRouteDefinitions()
                .doOnNext(route -> System.out.println("Route Loaded: " + route.getId()))
                .blockLast();
    }
}
