package com.niumapps.api_gateway.config;

import com.niumapps.api_gateway.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

/**
 * Global filter for JWT authentication in the API Gateway.
 * This filter intercepts all incoming requests and validates JWT tokens
 * either from the Authorization header or from a cookie named "jwt_token".
 *
 * The filter provides the following functionality:
 * 1. Exempts certain paths from authentication (login, register, logout, API docs)
 * 2. Extracts JWT token from Authorization header (Bearer token) or jwt_token cookie
 * 3. Validates the token using JwtUtil
 * 4. For successful login responses from upstream services, sets the jwt_token cookie
 * 5. For logout requests, clears the jwt_token cookie
 * 6. Returns 401 Unauthorized for invalid or missing tokens
 *
 * Token validation:
 * - Tokens must be signed with the shared secret key
 * - Tokens must not be expired
 * - Tokens must contain a valid subject (username)
 *
 * Cookie handling:
 * - Login: Sets HttpOnly cookie with JWT from upstream Authorization header
 * - Logout: Clears jwt_token cookie by setting MaxAge to 0
 * - Preference: Authorization header takes precedence over cookie when both are present
 *
 * Exempt paths (no authentication required):
 * - /auth/user/login
 * - /auth/user/register
 * - /auth/user/logout
 * - /v3/api-docs (Swagger API documentation)
 */
@Component
public class JwtAuthenticationFilter implements GlobalFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange,
                             GatewayFilterChain chain) {

        String path = exchange.getRequest().getURI().getPath();
        boolean skipAuth = path.equals("/auth/user/login") ||
                path.equals("/auth/user/register") ||
                path.equals("/auth/user/logout") ||
                path.contains("/v3/api-docs");

        String token = null;

        if (!skipAuth) {
            // Try to get token from cookie
            HttpCookie cookie = exchange.getRequest().getCookies().getFirst("jwt_token");
            if (cookie != null) {
                token = cookie.getValue();
            }
            // If not in cookie, try header
            if (token == null) {
                if (!exchange.getRequest().getHeaders()
                        .containsHeader(HttpHeaders.AUTHORIZATION)) {
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                    return exchange.getResponse().setComplete();
                }
                String header =
                        exchange.getRequest().getHeaders()
                                .getFirst(HttpHeaders.AUTHORIZATION);
                if (header == null || !header.startsWith("Bearer ")) {
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                    return exchange.getResponse().setComplete();
                }
                token = header.substring(7);
            }
            // Validate token
            if (!jwtUtil.validate(token)) {
                exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                return exchange.getResponse().setComplete();
            }
        }

        // Proceed with the request
        return chain.filter(exchange).then(Mono.fromRunnable(() -> {
            if (skipAuth) {
                HttpStatusCode status = exchange.getResponse().getStatusCode();
                if (path.equals("/auth/user/logout")) {
                    // Clear cookie on logout
                    ResponseCookie cookie = ResponseCookie.from("jwt_token", "")
                            .httpOnly(true)
                            .secure(false) // Set to true in production with HTTPS
                            .path("/")
                            .maxAge(Duration.ZERO)
                            .sameSite("Lax")
                            .build();
                    exchange.getResponse().getHeaders().add(HttpHeaders.SET_COOKIE, cookie.toString());
                } else if (status.is2xxSuccessful()) {
                    // Extract token from upstream response (user-service)
                    List<String> authHeaders = exchange.getResponse().getHeaders().get(HttpHeaders.AUTHORIZATION);
                    if (authHeaders != null && !authHeaders.isEmpty()) {
                        String authHeader = authHeaders.get(0);
                        if (authHeader.startsWith("Bearer ")) {
                            String tokenValue = authHeader.substring(7);
                            // Set cookie with the token
                            ResponseCookie cookie = ResponseCookie.from("jwt_token", tokenValue)
                                    .httpOnly(true)
                                    .secure(false) // Set to true in production with HTTPS
                                    .path("/")
                                    .maxAge(java.time.Duration.ofHours(1))
                                    .sameSite("Lax")
                                    .build();
                            exchange.getResponse().getHeaders().add(HttpHeaders.SET_COOKIE, cookie.toString());
                        }
                    }
                }
            }
        }));
    }
}