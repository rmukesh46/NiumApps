package com.niumapps.api_gateway.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;

/**
 * Utility class for JSON Web Token (JWT) operations.
 * Provides methods for token validation and claim extraction.
 *
 * This utility uses HMAC-SHA256 algorithm with a shared secret key
 * to sign and verify tokens. The same secret key must be used
 * across all services (user-service, card-service, api-gateway)
 * for token validation to work properly.
 *
 * The secret key is: "MyVeryLongSecretKeyForJwtAuthentication123456789"
 *
 * Tokens are expected to contain the following claims:
 * - subject (sub): The username of the authenticated user
 * - role: The role of the user (e.g., "USER", "ADMIN")
 *
 * This class does not provide token generation functionality -
 * that is handled by the user-service. This utility is focused
 * on validation and extraction of claims from existing tokens.
 *
 * Methods:
 * - validate(String token): Verifies token signature and expiration
 * - extractUsername(String token): Gets the username from token subject
 * - extractRole(String token): Gets the role from token claims
 */
@Component
public class JwtUtil {

    private static final String SECRET =
            "MyVeryLongSecretKeyForJwtAuthentication123456789";

    private final SecretKey key =
            Keys.hmacShaKeyFor(SECRET.getBytes());

    /**
     * Validates a JWT token.
     * Checks both the signature and expiration time.
     *
     * @param token The JWT token to validate
     * @return true if token is valid, false otherwise
     */
    public boolean validate(String token) {

        try {

            Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token);

            return true;

        } catch (Exception ex) {

            return false;

        }

    }

    /**
     * Extracts the username from a JWT token.
     * The username is stored in the "sub" (subject) claim.
     *
     * @param token The JWT token to extract from
     * @return The username, or null if token is invalid
     */
    public String extractUsername(String token) {

        Claims claims = Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();

        return claims.getSubject();
    }

    /**
     * Extracts the role from a JWT token.
     * The role is stored in a custom "role" claim.
     *
     * @param token The JWT token to extract from
     * @return The role, or null if token is invalid or role claim is missing
     */
    public String extractRole(String token) {

        Claims claims = Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();

        return claims.get("role", String.class);
    }
}