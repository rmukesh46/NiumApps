package com.niumapps.api_gateway;

import com.niumapps.api_gateway.config.JwtAuthenticationFilter;
import com.niumapps.api_gateway.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.MockServerWebExchange;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebSession;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Comprehensive unit tests for the API Gateway.
 * Focuses on JWT authentication filter and utility functions.
 */
@ExtendWith(MockitoExtension.class)
class ApiGatewayComprehensiveTest {

    // Mocks
    @Mock
    private JwtUtil jwtUtil;

    // Inject mocks into filter
    @InjectMocks
    private JwtAuthenticationFilter filter;

    // Test exchange
    private MockServerWebExchange mockExchange;
    private ServerWebExchange exchange;

    // Test data
    private static final String SECRET = "MyVeryLongSecretKeyForJwtAuthentication123456789";
    private final String VALID_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.valid";
    private final String INVALID_TOKEN = "invalid.token.here";
    private final String EXPIRED_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.expired";
    private final String TEST_USER = "testuser";
    private final String TEST_ROLE = "USER";

    @BeforeEach
    void setUp() {
        mockExchange = new MockServerWebExchange();
        exchange = mockExchange;
    }

    /**
     * Test suite for JwtAuthenticationFilter
     */
    @Nested
    @DisplayName("JWT Authentication Filter Tests")
    class JwtAuthenticationFilterTests {

        @Test
        @DisplayName("Should allow access to exempt paths without authentication")
        @DisplayName("Exempt paths: login, register, logout, api-docs")
        void testFilterExemptPaths() {
            // Test each exempt path
            String[] exemptPaths = {
                    "/auth/user/login",
                    "/auth/user/register",
                    "/auth/user/logout",
                    "/v3/api-docs"
            };

            for (String path : exemptPaths) {
                // Arrange
                mockExchange.getRequest().mutate().path(path);
                // No authentication needed for exempt paths

                // Act
                Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                        (ServerWebExchange innerExchange) -> {
                            // Simple chain that just returns empty mono
                            return Mono.empty();
                        });

                // Assert
                assertNotNull(result, "Should return non-null mono for exempt path: " + path);
                // For exempt paths, we should proceed without authentication
                verify(jwtUtil, never()).validate(anyString());
            }
        }

        @Test
        @DisplayName("Should return unauthorized when no token provided")
        void testFilterMissingToken() {
            // Arrange
            mockExchange.getRequest().mutate().path("/some-protected-path");
            // No cookies, no auth header

            // Act
            Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                    (ServerWebExchange innerExchange) -> Mono.empty());

            // Assert
            assertNotNull(result);
            assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode(),
                    "Should return 401 when no token provided");
        }

        @Test
        @DisplayName("Should return unauthorized when auth header missing")
        void testFilterMissingAuthHeader() {
            // Arrange
            mockExchange.getRequest().mutate().path("/some-protected-path");
            // No auth header, but add a different cookie to ensure it's not using cookie
            mockExchange.getRequest().getCookies().put("other_cookie",
                    new HttpCookie("other_cookie", "value"));

            // Act
            Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                    (ServerWebExchange innerExchange) -> Mono.empty());

            // Assert
            assertNotNull(result);
            assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode(),
                    "Should return 401 when auth header missing");
        }

        @Test
        @DisplayName("Should return unauthorized when token in header is invalid")
        void testFilterInvalidTokenInHeader() {
            // Arrange
            mockExchange.getRequest().mutate().path("/some-protected-path");
            mockExchange.getRequest().getHeaders().set(HttpHeaders.AUTHORIZATION,
                    "Bearer " + INVALID_TOKEN);

            when(jwtUtil.validate(INVALID_TOKEN)).thenReturn(false);

            // Act
            Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                    (ServerWebExchange innerExchange) -> Mono.empty());

            // Assert
            assertNotNull(result);
            assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode(),
                    "Should return 401 when token is invalid");
            verify(jwtUtil).validate(INVALID_TOKEN);
        }

        @Test
        @DisplayName("Should allow access when token in header is valid")
        void testFilterValidTokenInHeader() {
            // Arrange
            mockExchange.getRequest().mutate().path("/some-protected-path");
            mockExchange.getRequest().getHeaders().set(HttpHeaders.AUTHORIZATION,
                    "Bearer " + VALID_TOKEN);

            when(jwtUtil.validate(VALID_TOKEN)).thenReturn(true);

            // Act
            Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                    (ServerWebExchange innerExchange) -> Mono.empty());

            // Assert
            assertNotNull(result);
            // Should proceed with the request (return empty mono to indicate continuation)
            verify(jwtUtil).validate(VALID_TOKEN);
        }

        @Test
        @DisplayName("Should allow access when valid token is in cookie")
        void testFilterValidTokenInCookie() {
            // Arrange
            mockExchange.getRequest().mutate().path("/some-protected-path");
            mockExchange.getRequest().getCookies().put("jwt_token",
                    new HttpCookie("jwt_token", VALID_TOKEN));
            // No auth header - should use cookie

            when(jwtUtil.validate(VALID_TOKEN)).thenReturn(true);

            // Act
            Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                    (ServerWebExchange innerExchange) -> Mono.empty());

            // Assert
            assertNotNull(result);
            // Should proceed with the request
            verify(jwtUtil).validate(VALID_TOKEN);
        }

        @Test
        @DisplayName("Should prefer token in header over cookie when both present")
        void testFilterHeaderTakesPrecedenceOverCookie() {
            // Arrange
            mockExchange.getRequest().mutate().path("/some-protected-path");
            String headerToken = "Bearer headervalidtoken";
            String cookieToken = "cookieinvalidtoken";

            mockExchange.getRequest().getHeaders().set(HttpHeaders.AUTHORIZATION, headerToken);
            mockExchange.getRequest().getCookies().put("jwt_token",
                    new HttpCookie("jwt_token", cookieToken));

            // Header token is valid, cookie token is invalid
            when(jwtUtil.validate("headervalidtoken")).thenReturn(true);
            when(jwtUtil.validate("cookieinvalidtoken")).thenReturn(false);

            // Act
            Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                    (ServerWebExchange innerExchange) -> Mono.empty());

            // Assert
            assertNotNull(result);
            // Should proceed with the request using header token
            verify(jwtUtil).validate("headervalidtoken");
            verify(jwtUtil, never()).validate("cookieinvalidtoken");
        }

        @Test
        @DisplayName("Should set JWT cookie on successful login")
        void testFilterSetsCookieOnLoginSuccess() throws Exception {
            // Arrange
            mockExchange.getRequest().mutate().path("/auth/user/login");
            mockExchange.getResponse().setStatusCode(HttpStatus.OK);

            // Act
            Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                    (ServerWebExchange innerExchange) -> {
                        // Simulate upstream response with Authorization header
                        innerExchange.getResponse().getHeaders()
                                .add(HttpHeaders.AUTHORIZATION, "Bearer upstreamtoken");
                        return Mono.empty();
                    });

            // Assert
            assertNotNull(result);
            // Should have set cookie in response
            assertTrue(exchange.getResponse().getHeaders().containsKey(HttpHeaders.SET_COOKIE),
                    "Should set cookie on login");
            List<String> setCookieHeaders = exchange.getResponse().getHeaders()
                    .get(HttpHeaders.SET_COOKIE);
            assertFalse(setCookieHeaders.isEmpty(), "Should have at least one Set-Cookie header");
            String cookieHeader = setCookieHeaders.get(0);
            assertTrue(cookieHeader.contains("jwt_token=upstreamtoken"),
                    "Should contain the token from upstream response");
            assertTrue(cookieHeader.contains("HttpOnly"), "Should be HttpOnly");
            assertTrue(cookieHeader.contains("Path=/"), "Should have path /");
        }

        @Test
        @DisplayName("Should clear JWT cookie on logout")
        void testFilterClearsCookieOnLogout() throws Exception {
            // Arrange
            mockExchange.getRequest().mutate().path("/auth/user/logout");
            mockExchange.getResponse().setStatusCode(HttpStatus.OK);

            // Act
            Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(),
                    (ServerWebExchange innerExchange) -> Mono.empty());

            // Assert
            assertNotNull(result);
            // Should have cleared cookie in response
            assertTrue(exchange.getResponse().getHeaders().containsKey(HttpHeaders.SET_COOKIE),
                    "Should set cookie on logout");
            List<String> setCookieHeaders = exchange.getResponse().getHeaders()
                    .get(HttpHeaders.SET_COOKIE);
            assertFalse(setCookieHeaders.isEmpty(), "Should have at least one Set-Cookie header");
            String cookieHeader = setCookieHeaders.get(0);
            assertTrue(cookieHeader.contains("jwt_token="), "Should contain jwt_token");
            assertTrue(cookieHeader.contains("MaxAge=0"), "Should expire cookie immediately");
        }
    }

    /**
     * Test suite for JwtUtil
     */
    @Nested
    @DisplayName("JWT Utility Tests")
    class JwtUtilTests {

        private JwtUtil jwtUtil;
        private String secret;
        private io.jsonwebtoken.security.SecretKey key;

        @BeforeEach
        void setUp() {
            secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
            key = io.jsonwebtoken.security.Keys.hmacShaKeyFor(secret.getBytes());
            jwtUtil = new JwtUtil();
        }

        @Test
        @DisplayName("Should validate valid token")
        void testValidateTokenValid() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USER)
                    .claim("role", TEST_ROLE)
                    .signWith(key)
                    .compact();

            // Act
            boolean isValid = jwtUtil.validate(token);

            // Assert
            assertTrue(isValid, "Valid token should pass validation");
        }

        @Test
        @DisplayName("Should reject token with invalid signature")
        void testValidateTokenInvalidSignature() {
            // Arrange
            String wrongSecret = "wrongsecret";
            io.jsonwebtoken.security.SecretKey wrongKey =
                    io.jsonwebtoken.security.Keys.hmacShaKeyFor(wrongSecret.getBytes());
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USER)
                    .claim("role", TEST_ROLE)
                    .signWith(wrongKey)
                    .compact();

            // Act
            boolean isValid = jwtUtil.validate(token);

            // Assert
            assertFalse(isValid, "Token with wrong signature should fail validation");
        }

        @Test
        @DisplayName("Should reject expired token")
        void testValidateTokenExpired() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USER)
                    .claim("role", TEST_ROLE)
                    .expiration(new java.util.Date(System.currentTimeMillis() - 1000)) // Expired 1 second ago
                    .signWith(key)
                    .compact();

            // Act
            boolean isValid = jwtUtil.validate(token);

            // Assert
            assertFalse(isValid, "Expired token should fail validation");
        }

        @Test
        @DisplayName("Should extract username from valid token")
        void testExtractUsername() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USER)
                    .claim("role", TEST_ROLE)
                    .signWith(key)
                    .compact();

            // Act
            String username = jwtUtil.extractUsername(token);

            // Assert
            assertEquals(TEST_USER, username, "Should extract correct username");
        }

        @Test
        @DisplayName("Should extract role from valid token")
        void testExtractRole() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USER)
                    .claim("role", TEST_ROLE)
                    .signWith(key)
                    .compact();

            // Act
            String role = jwtUtil.extractRole(token);

            // Assert
            assertEquals(TEST_ROLE, role, "Should extract correct role");
        }

        @Test
        @DisplayName("Should return null for invalid token")
        void testExtractUsernameInvalidToken() {
            // Act
            String username = jwtUtil.extractUsername("invalid.token.here");

            // Assert
            assertNull(username, "Should return null for invalid token");
        }

        @Test
        @DisplayName("Should handle token with no role claim")
        void testExtractRoleMissingClaim() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USER)
                    // No role claim
                    .signWith(key)
                    .compact();

            // Act
            String role = jwtUtil.extractRole(token);

            // Assert
            assertNull(role, "Should return null when role claim is missing");
        }
    }
}