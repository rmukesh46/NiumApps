package com.niumapps.api_gateway;

import com.niumapps.api_gateway.util.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.crypto.SecretKey;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JwtUtilTest {

    @InjectMocks
    private JwtUtil jwtUtil;

    private static final String SECRET = "MyVeryLongSecretKeyForJwtAuthentication123456789";
    private SecretKey key;

    @BeforeEach
    void setUp() {
        key = Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    @Test
    void testValidateTokenValid() {
        // Arrange
        String token = Jwts.builder()
                .subject("testuser")
                .claim("role", "USER")
                .signWith(key)
                .compact();

        // Act
        boolean isValid = jwtUtil.validate(token);

        // Assert
        assertTrue(isValid);
    }

    @Test
    void testValidateTokenInvalidSignature() {
        // Arrange
        String wrongSecret = "wrongsecret";
        SecretKey wrongKey = Keys.hmacShaKeyFor(wrongSecret.getBytes());
        String token = Jwts.builder()
                .subject("testuser")
                .claim("role", "USER")
                .signWith(wrongKey)
                .compact();

        // Act
        boolean isValid = jwtUtil.validate(token);

        // Assert
        assertFalse(isValid);
    }

    @Test
    void testValidateTokenExpired() {
        // Arrange
        String token = Jwts.builder()
                .subject("testuser")
                .claim("role", "USER")
                .expiration(new Date(System.currentTimeMillis() - 1000)) // Expired 1 second ago
                .signWith(key)
                .compact();

        // Act
        boolean isValid = jwtUtil.validate(token);

        // Assert
        assertFalse(isValid);
    }

    @Test
    void testExtractUsername() {
        // Arrange
        String token = Jwts.builder()
                .subject("testuser")
                .claim("role", "USER")
                .signWith(key)
                .compact();

        // Act
        String username = jwtUtil.extractUsername(token);

        // Assert
        assertEquals("testuser", username);
    }

    @Test
    void testExtractRole() {
        // Arrange
        String token = Jwts.builder()
                .subject("testuser")
                .claim("role", "USER")
                .signWith(key)
                .compact();

        // Act
        String role = jwtUtil.extractRole(token);

        // Assert
        assertEquals("USER", role);
    }

    @Test
    void testExtractUsernameInvalidToken() {
        // Act
        String username = jwtUtil.extractUsername("invalid.token.here");

        // Assert
        assertNull(username);
    }
}