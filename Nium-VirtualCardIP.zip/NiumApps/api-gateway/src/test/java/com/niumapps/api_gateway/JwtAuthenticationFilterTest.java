package com.niumapps.api_gateway;

import com.niumapps.api_gateway.config.JwtAuthenticationFilter;
import com.niumapps.api_gateway.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.MockServerWebExchange;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebSession;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JwtAuthenticationFilterTest {

    @InjectMocks
    private JwtAuthenticationFilter filter;

    @Mock
    private JwtUtil jwtUtil;

    private ServerWebExchange exchange;
    private MockServerWebExchange mockExchange;

    @BeforeEach
    void setUp() {
        mockExchange = new MockServerWebExchange();
        exchange = mockExchange;
    }

    @Test
    void testFilterExemptPathLogin() {
        // Arrange
        mockExchange.getRequest().mutate().path("/auth/user/login");
        when(jwtUtil.validate(anyString())).thenReturn(true); // This shouldn't be called for exempt paths

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        // For exempt paths, we should proceed without authentication
        verify(jwtUtil, never()).validate(anyString());
    }

    @Test
    void testFilterExemptPathRegister() {
        // Arrange
        mockExchange.getRequest().mutate().path("/auth/user/register");
        when(jwtUtil.validate(anyString())).thenReturn(true); // This shouldn't be called for exempt paths

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        verify(jwtUtil, never()).validate(anyString());
    }

    @Test
    void testFilterExemptPathLogout() {
        // Arrange
        mockExchange.getRequest().mutate().path("/auth/user/logout");
        when(jwtUtil.validate(anyString())).thenReturn(true); // This shouldn't be called for exempt paths

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        verify(jwtUtil, never()).validate(anyString());
    }

    @Test
    void testFilterExemptPathApiDocs() {
        // Arrange
        mockExchange.getRequest().mutate().path("/v3/api-docs");
        when(jwtUtil.validate(anyString())).thenReturn(true); // This shouldn't be called for exempt paths

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        verify(jwtUtil, never()).validate(anyString());
    }

    @Test
    void testFilterMissingToken() {
        // Arrange
        mockExchange.getRequest().mutate().path("/some-protected-path");
        // No cookies, no auth header

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void testFilterMissingAuthHeader() {
        // Arrange
        mockExchange.getRequest().mutate().path("/some-protected-path");
        // No auth header, but we'll add a cookie to make sure it's not using cookie
        mockExchange.getRequest().getCookies().put("other_cookie", HttpCookie("other_cookie", "value"));

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void testFilterInvalidTokenInHeader() {
        // Arrange
        mockExchange.getRequest().mutate().path("/some-protected-path");
        mockExchange.getRequest().getHeaders().set(HttpHeaders.AUTHORIZATION, "Bearer invalidtoken");

        when(jwtUtil.validate("invalidtoken")).thenReturn(false);

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
        verify(jwtUtil).validate("invalidtoken");
    }

    @Test
    void testFilterValidTokenInHeader() {
        // Arrange
        mockExchange.getRequest().mutate().path("/some-protected-path");
        mockExchange.getRequest().getHeaders().set(HttpHeaders.AUTHORIZATION, "Bearer validtoken");

        when(jwtUtil.validate("validtoken")).thenReturn(true);

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        // Should proceed with the request
        verify(jwtUtil).validate("validtoken");
    }

    @Test
    void testFilterValidTokenInCookie() {
        // Arrange
        mockExchange.getRequest().mutate().path("/some-protected-path");
        mockExchange.getRequest().getCookies().put("jwt_token", HttpCookie("jwt_token", "validcookietoken"));
        // No auth header

        when(jwtUtil.validate("validcookietoken")).thenReturn(true);

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        // Should proceed with the request
        verify(jwtUtil).validate("validcookietoken");
    }

    @Test
    void testFilterTokenInHeaderTakesPrecedenceOverCookie() {
        // Arrange
        mockExchange.getRequest().mutate().path("/some-protected-path");
        mockExchange.getRequest().getHeaders().set(HttpHeaders.AUTHORIZATION, "Bearer headervalidtoken");
        mockExchange.getRequest().getCookies().put("jwt_token", HttpCookie("jwt_token", "cookieinvalidtoken"));

        when(jwtUtil.validate("headervalidtoken")).thenReturn(true);
        when(jwtUtil.validate("cookieinvalidtoken")).thenReturn(false);

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        // Should proceed with the request using header token
        verify(jwtUtil).validate("headervalidtoken");
        verify(jwtUtil, never()).validate("cookieinvalidtoken");
    }

    @Test
    void testFilterSetsCookieOnLoginSuccess() throws Exception {
        // Arrange
        mockExchange.getRequest().mutate().path("/auth/user/login");
        mockExchange.getResponse().setStatusCode(HttpStatus.OK);

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            // Simulate upstream response with Authorization header
            innerExchange.getResponse().getHeaders().add(HttpHeaders.AUTHORIZATION, "Bearer upstreamtoken");
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        // Should have set cookie in response
        assertTrue(exchange.getResponse().getHeaders().containsKey(HttpHeaders.SET_COOKIE));
        List<String> setCookieHeaders = exchange.getResponse().getHeaders().get(HttpHeaders.SET_COOKIE);
        assertTrue(setCookieHeaders.get(0).contains("jwt_token=upstreamtoken"));
        assertTrue(setCookieHeaders.get(0).contains("HttpOnly"));
        assertTrue(setCookieHeaders.get(0).contains("Path=/"));
    }

    @Test
    void testFilterClearsCookieOnLogout() throws Exception {
        // Arrange
        mockExchange.getRequest().mutate().path("/auth/user/logout");
        mockExchange.getResponse().setStatusCode(HttpStatus.OK);

        // Act
        Mono<Void> result = filter.filter(exchange, mockExchange.getRequest(), (ServerWebExchange innerExchange, MockServerWebExchange.MockGatewayFilterChain chain) -> {
            return chain.filter(innerExchange);
        });

        // Assert
        assertNotNull(result);
        // Should have cleared cookie in response
        assertTrue(exchange.getResponse().getHeaders().containsKey(HttpHeaders.SET_COOKIE));
        List<String> setCookieHeaders = exchange.getResponse().getHeaders().get(HttpHeaders.SET_COOKIE);
        assertTrue(setCookieHeaders.get(0).contains("jwt_token="));
        assertTrue(setCookieHeaders.get(0).contains("MaxAge=0")); // Cookie expired
    }

    // Helper method to create HttpCookie
    private HttpCookie HttpCookie(String name, String value) {
        HttpCookie cookie = new HttpCookie(name, value);
        cookie.setPath("/");
        return cookie;
    }
}