package com.niumapps.user_service.service;

import com.niumapps.user_service.entity.User;
import com.niumapps.user_service.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service layer for user management operations.
 * Handles user creation, retrieval, and listing.
 *
 * This service interacts with the UserRepository to perform CRUD operations
 * on User entities. It ensures that usernames are unique and provides
 * methods to fetch user information.
 */
@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Creates a new user in the system.
     * Checks if a user with the same username already exists.
     *
     * @param user The user object to create (password should be plain text)
     * @return The created user object with ID populated, or null if username already exists
     */
    public User createUser(User user) {
        if (this.getUserById(user.getUsername()) != null) {
            return null;
        }
        return userRepository.save(user);
    }

    /**
     * Retrieves all users in the system.
     *
     * @return List of all users
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Retrieves a user by their username.
     *
     * @param username The username to search for
     * @return The user object if found, null otherwise
     */
    public User getUserById(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }
}