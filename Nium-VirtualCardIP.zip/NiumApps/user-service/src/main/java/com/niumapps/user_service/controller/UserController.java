package com.niumapps.user_service.controller;

import com.niumapps.user_service.config.SecurityConfig;
import com.niumapps.user_service.entity.User;
import com.niumapps.user_service.service.UserService;
import com.niumapps.user_service.util.JwtUtil;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.List;

/**
 * REST controller for user management endpoints.
 * Handles user registration, login, logout, and user information retrieval.
 *
 * All endpoints are prefixed with "/auth/user" and require appropriate
 * authentication where noted.
 *
 * Endpoints:
 * - POST /register: Register a new user
 * - GET /login: Login with username and password (returns JWT token)
 * - POST /logout: Logout and clear JWT cookie
 * - GET /: Get all users
 * - GET /{username}: Get user by username
 */
@RestController
@RequestMapping("/auth/user")
public class UserController {

    private final SecurityConfig securityConfig;
    private final UserService userService;
    private final JwtUtil jwtUtil;

    public UserController(SecurityConfig securityConfig, UserService userService, JwtUtil jwtUtil) {
        this.securityConfig = securityConfig;
        this.userService = userService;
        this.jwtUtil = jwtUtil;
    }

    /**
     * Registers a new user.
     * The password is encoded using BCrypt before storage.
     *
     * @param user User object containing username and plain text password
     * @return Response entity with status and created username, or error message
     */
    @PostMapping("/register")
    public ResponseEntity<String> createUser(@RequestBody User user) {
        user.setPassword(securityConfig.passwordEncoder().encode(user.getPassword()));
        User userAdded = userService.createUser(user);
        if (userAdded == null) {
            return ResponseEntity.badRequest().body("USER : " + user.getUsername()
                    +" Already Exist");
        }
        return ResponseEntity.ok(userAdded.getUsername());
    }

    /**
     * Authenticates a user and returns a JWT token.
     * Validates username and password, then generates a signed JWT token.
     *
     * @param username The username to authenticate
     * @param password The plain text password to validate
     * @return Response entity with login status and JWT token in Authorization header
     */
    @GetMapping("/login")
    public ResponseEntity<String> loginUser(@RequestParam String username,
                                            @RequestParam String password) {
        User user = userService.getUserById(username);
        if (user == null || !securityConfig.passwordEncoder().matches(password, user.getPassword())) {
            return ResponseEntity.status(401).body("Invalid username or password");
        }
        String token = jwtUtil.generateToken(username, "USER");
        return ResponseEntity.ok()
                .header("Authorization", "Bearer " + token)
                .body("Login successful");
    }

    /**
     * Logs out the current user by clearing the JWT cookie.
     *
     * @return Response entity with logout status and empty JWT cookie
     */
    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        ResponseCookie cookie = ResponseCookie.from("jwt_token", "")
                .httpOnly(true)
                .secure(false)
                .path("/")
                .maxAge(Duration.ZERO)
                .sameSite("Lax")
                .build();
        return ResponseEntity.ok()
                .header("Set-Cookie", cookie.toString())
                .body("Logged out");
    }

    /**
     * Retrieves all users in the system.
     *
     * @return List of all users
     */
    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    /**
     * Retrieves a user by their username.
     *
     * @param username The username to search for
     * @return The user object if found
     */
    @GetMapping("/{username}")
    public User getUserById(@PathVariable String username) {
        return userService.getUserById(username);
    }
}