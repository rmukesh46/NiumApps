package com.niumapps.user_service;

import com.niumapps.user_service.config.SecurityConfig;
import com.niumapps.user_service.controller.UserController;
import com.niumapps.user_service.entity.User;
import com.niumapps.user_service.service.UserService;
import com.niumapps.user_service.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @InjectMocks
    private UserController userController;

    @Mock
    private SecurityConfig securityConfig;

    @Mock
    private UserService userService;

    @Mock
    private JwtUtil jwtUtil;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setUsername("testuser");
        testUser.setPassword("encodedpassword");
    }

    @Test
    void testCreateUserSuccess() {
        // Arrange
        User newUser = new User();
        newUser.setUsername("newuser");
        newUser.setPassword("plainpassword");

        when(securityConfig.passwordEncoder().encode("plainpassword")).thenReturn("encodedpassword");
        when(userService.createUser(any(User.class))).thenReturn(newUser);

        // Act
        ResponseEntity<String> response = userController.createUser(newUser);

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("newuser", response.getBody());
        verify(userService).createUser(any(User.class));
    }

    @Test
    void testCreateUserDuplicate() {
        // Arrange
        User existingUser = new User();
        existingUser.setUsername("testuser");
        existingUser.setPassword("password");

        when(userService.createUser(any(User.class))).thenReturn(null);

        // Act
        ResponseEntity<String> response = userController.createUser(existingUser);

        // Assert
        assertEquals(400, response.getStatusCodeValue());
        assertTrue(response.getBody().contains("Already Exist"));
    }

    @Test
    void testLoginUserSuccess() {
        // Arrange
        when(userService.getUserById("testuser")).thenReturn(testUser);
        when(securityConfig.passwordEncoder().matches("password", "encodedpassword")).thenReturn(true);
        when(jwtUtil.generateToken("testuser", "USER")).thenReturn("fake-token");

        // Act
        ResponseEntity<String> response = userController.loginUser("testuser", "password");

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Login successful", response.getBody());
        assertTrue(response.getHeaders().containsKey("Authorization"));
        assertEquals("Bearer fake-token", response.getHeaders().getFirst("Authorization"));
    }

    @Test
    void testLoginUserInvalidUsername() {
        // Arrange
        when(userService.getUserById("nonexistent")).thenReturn(null);

        // Act
        ResponseEntity<String> response = userController.loginUser("nonexistent", "password");

        // Assert
        assertEquals(401, response.getStatusCodeValue());
        assertEquals("Invalid username or password", response.getBody());
    }

    @Test
    void testLoginUserInvalidPassword() {
        // Arrange
        when(userService.getUserById("testuser")).thenReturn(testUser);
        when(securityConfig.passwordEncoder().matches("wrongpassword", "encodedpassword")).thenReturn(false);

        // Act
        ResponseEntity<String> response = userController.loginUser("testuser", "wrongpassword");

        // Assert
        assertEquals(401, response.getStatusCodeValue());
        assertEquals("Invalid username or password", response.getBody());
    }

    @Test
    void testLogout() {
        // Act
        ResponseEntity<String> response = userController.logout();

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Logged out", response.getBody());
        assertTrue(response.getHeaders().containsKey("Set-Cookie"));

        // Verify cookie properties
        List<String> setCookieHeaders = response.getHeaders().get("Set-Cookie");
        assertTrue(setCookieHeaders.get(0).contains("jwt_token="));
        assertTrue(setCookieHeaders.get(0).contains("HttpOnly"));
        assertTrue(setCookieHeaders.get(0).contains("Path=/"));
        assertTrue(setCookieHeaders.get(0).contains("MaxAge=0"));
    }

    @Test
    void testGetAllUsers() {
        // Arrange
        User user1 = new User();
        user1.setId(1L);
        user1.setUsername("user1");
        user1.setPassword("pass1");

        User user2 = new User();
        user2.setId(2L);
        user2.setUsername("user2");
        user2.setPassword("pass2");

        when(userService.getAllUsers()).thenReturn(Arrays.asList(user1, user2));

        // Act
        List<User> users = userController.getAllUsers();

        // Assert
        assertNotNull(users);
        assertEquals(2, users.size());
        assertEquals("user1", users.get(0).getUsername());
        assertEquals("user2", users.get(1).getUsername());
    }

    @Test
    void testGetUserByIdSuccess() {
        // Arrange
        when(userService.getUserById("testuser")).thenReturn(testUser);

        // Act
        User user = userController.getUserById("testuser");

        // Assert
        assertNotNull(user);
        assertEquals("testuser", user.getUsername());
        assertEquals(1L, user.getId());
    }

    @Test
    void testGetUserByIdNotFound() {
        // Arrange
        when(userService.getUserById("nonexistent")).thenReturn(null);

        // Act
        User user = userController.getUserById("nonexistent");

        // Assert
        assertNull(user);
    }
}