package com.niumapps.user_service;

import com.niumapps.user_service.config.SecurityConfig;
import com.niumapps.user_service.controller.UserController;
import com.niumapps.user_service.entity.User;
import com.niumapps.user_service.repository.UserRepository;
import com.niumapps.user_service.service.UserService;
import com.niumapps.user_service.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;

import io.jsonwebtoken.security.Keys;
import javax.crypto.SecretKey;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Comprehensive unit tests for the User Service.
 * Covers UserController, UserService, UserRepository, SecurityConfig, and JwtUtil.
 */
@ExtendWith(MockitoExtension.class)
class UserServiceComprehensiveTest {

    // Mocks
    @Mock
    private SecurityConfig securityConfig;

    @Mock
    private UserService userService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private JwtUtil jwtUtil;

    // Inject mocks into controller
    @InjectMocks
    private UserController userController;

    // Test data
    private User testUser;
    private final String TEST_USERNAME = "testuser";
    private final String TEST_PASSWORD = "password123";
    private final String ENCODED_PASSWORD = "$2a$10$encodedpasswordhash";
    private final String VALID_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.valid.token";

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setUsername(TEST_USERNAME);
        testUser.setPassword(ENCODED_PASSWORD);
    }

    /**
     * Test suite for UserController
     */
    @Nested
    @DisplayName("User Controller Tests")
    class UserControllerTests {

        @Test
        @DisplayName("Should create user successfully when username doesn't exist")
        void testCreateUserSuccess() {
            // Arrange
            User newUser = new User();
            newUser.setUsername("newuser");
            newUser.setPassword("plainpassword");

            when(securityConfig.passwordEncoder().encode("plainpassword")).thenReturn(ENCODED_PASSWORD);
            when(userService.createUser(any(User.class))).thenReturn(newUser);

            // Act
            ResponseEntity<String> response = userController.createUser(newUser);

            // Assert
            assertEquals(200, response.getStatusCode(), "Should return HTTP 200 OK");
            assertEquals("newuser", response.getBody(), "Should return created username");
            verify(userService).createUser(any(User.class));
            verify(securityConfig).passwordEncoder();
        }

        @Test
        @DisplayName("Should return bad request when trying to create duplicate user")
        void testCreateUserDuplicate() {
            // Arrange
            User existingUser = new User();
            existingUser.setUsername(TEST_USERNAME);
            existingUser.setPassword("password");

            when(userService.createUser(any(User.class))).thenReturn(null);

            // Act
            ResponseEntity<String> response = userController.createUser(existingUser);

            // Assert
            assertEquals(400, response.getStatusCode(), "Should return HTTP 400 Bad Request");
            assertTrue(response.getBody().contains("Already Exist"),
                    "Should indicate user already exists");
        }

        @Test
        @DisplayName("Should login user successfully with valid credentials")
        void testLoginUserSuccess() {
            // Arrange
            when(userService.getUserById(TEST_USERNAME)).thenReturn(testUser);
            when(securityConfig.passwordEncoder().matches(TEST_PASSWORD, ENCODED_PASSWORD)).thenReturn(true);
            when(jwtUtil.generateToken(TEST_USERNAME, "USER")).thenReturn(VALID_TOKEN);

            // Act
            ResponseEntity<String> response = userController.loginUser(TEST_USERNAME, TEST_PASSWORD);

            // Assert
            assertEquals(200, response.getStatusCode(), "Should return HTTP 200 OK");
            assertEquals("Login successful", response.getBody(), "Should return success message");
            assertNotNull(response.getHeaders().get("Authorization"),
                    "Should include Authorization header");
            assertEquals("Bearer " + VALID_TOKEN,
                    response.getHeaders().getFirst("Authorization"),
                    "Should include correct bearer token");
        }

        @Test
        @DisplayName("Should return unauthorized for invalid username")
        void testLoginUserInvalidUsername() {
            // Arrange
            when(userService.getUserById("nonexistent")).thenReturn(null);

            // Act
            ResponseEntity<String> response = userController.loginUser("nonexistent", TEST_PASSWORD);

            // Assert
            assertEquals(401, response.getStatusCode(), "Should return HTTP 401 Unauthorized");
            assertEquals("Invalid username or password", response.getBody(),
                    "Should return invalid credentials message");
        }

        @Test
        @DisplayName("Should return unauthorized for invalid password")
        void testLoginUserInvalidPassword() {
            // Arrange
            when(userService.getUserById(TEST_USERNAME)).thenReturn(testUser);
            when(securityConfig.passwordEncoder().matches("wrongpassword", ENCODED_PASSWORD)).thenReturn(false);

            // Act
            ResponseEntity<String> response = userController.loginUser(TEST_USERNAME, "wrongpassword");

            // Assert
            assertEquals(401, response.getStatusCode(), "Should return HTTP 401 Unauthorized");
            assertEquals("Invalid username or password", response.getBody(),
                    "Should return invalid credentials message");
        }

        @Test
        @DisplayName("Should logout user and clear JWT cookie")
        void testLogout() {
            // Act
            ResponseEntity<String> response = userController.logout();

            // Assert
            assertEquals(200, response.getStatusCode(), "Should return HTTP 200 OK");
            assertEquals("Logged out", response.getBody(), "Should return logout message");
            assertNotNull(response.getHeaders().get("Set-Cookie"),
                    "Should include Set-Cookie header");

            // Verify cookie properties
            List<String> setCookieHeaders = response.getHeaders().get("Set-Cookie");
            assertFalse(setCookieHeaders.isEmpty(), "Should have at least one Set-Cookie header");
            String cookieHeader = setCookieHeaders.get(0);
            assertTrue(cookieHeader.contains("jwt_token="), "Should include jwt_token cookie");
            assertTrue(cookieHeader.contains("HttpOnly"), "Should be HttpOnly");
            assertTrue(cookieHeader.contains("Path=/"), "Should have path /");
            assertTrue(cookieHeader.contains("MaxAge=0"), "Should expire immediately");
        }

        @Test
        @DisplayName("Should return all users")
        void testGetAllUsers() {
            // Arrange
            User user1 = new User();
            user1.setId(1L);
            user1.setUsername("user1");
            user1.setPassword("pass1");

            User user2 = new User();
            user2.setId(2L);
            user2.setUsername("user2");
            user2.setPassword("pass2");

            when(userService.getAllUsers()).thenReturn(Arrays.asList(user1, user2));

            // Act
            List<User> users = userController.getAllUsers();

            // Assert
            assertNotNull(users, "Should return non-null list");
            assertEquals(2, users.size(), "Should return exactly 2 users");
            assertEquals("user1", users.get(0).getUsername(), "First user should be user1");
            assertEquals("user2", users.get(1).getUsername(), "Second user should be user2");
        }

        @Test
        @DisplayName("Should return user by ID when exists")
        void testGetUserByIdSuccess() {
            // Arrange
            when(userService.getUserById(TEST_USERNAME)).thenReturn(testUser);

            // Act
            User user = userController.getUserById(TEST_USERNAME);

            // Assert
            assertNotNull(user, "Should return non-null user");
            assertEquals(TEST_USERNAME, user.getUsername(), "Should return correct username");
            assertEquals(1L, user.getId(), "Should return correct user ID");
        }

        @Test
        @DisplayName("Should return null when user not found by ID")
        void testGetUserByIdNotFound() {
            // Arrange
            when(userService.getUserById("nonexistent")).thenReturn(null);

            // Act
            User user = userController.getUserById("nonexistent");

            // Assert
            assertNull(user, "Should return null for non-existent user");
        }
    }

    /**
     * Test suite for UserService
     */
    @Nested
    @DisplayName("User Service Tests")
    class UserServiceTests {

        @Test
        @DisplayName("Should create user when username doesn't exist")
        void testCreateUserSuccess() {
            // Arrange
            when(userRepository.findByUsername(TEST_USERNAME)).thenReturn(Optional.empty());
            when(userRepository.save(any(User.class))).thenReturn(testUser);

            // Act
            User createdUser = userService.createUser(testUser);

            // Assert
            assertNotNull(createdUser, "Should return created user");
            assertEquals(TEST_USERNAME, createdUser.getUsername(), "Should have correct username");
            verify(userRepository).findByUsername(TEST_USERNAME);
            verify(userRepository).save(testUser);
        }

        @Test
        @DisplayName("Should not create user when username already exists")
        void testCreateUserDuplicate() {
            // Arrange
            when(userRepository.findByUsername(TEST_USERNAME)).thenReturn(Optional.of(testUser));

            // Act
            User createdUser = userService.createUser(testUser);

            // Assert
            assertNull(createdUser, "Should return null for duplicate user");
            verify(userRepository).findByUsername(TEST_USERNAME);
            verify(userRepository, never()).save(any(User.class));
        }

        @Test
        @DisplayName("Should retrieve user by ID when exists")
        void testGetUserByIdSuccess() {
            // Arrange
            when(userRepository.findByUsername(TEST_USERNAME)).thenReturn(Optional.of(testUser));

            // Act
            User user = userService.getUserById(TEST_USERNAME);

            // Assert
            assertNotNull(user, "Should return user");
            assertEquals(TEST_USERNAME, user.getUsername(), "Should have correct username");
            verify(userRepository).findByUsername(TEST_USERNAME);
        }

        @Test
        @DisplayName("Should return null when user not found by ID")
        void testGetUserByIdNotFound() {
            // Arrange
            when(userRepository.findByUsername("nonexistent")).thenReturn(Optional.empty());

            // Act
            User user = userService.getUserById("nonexistent");

            // Assert
            assertNull(user, "Should return null for non-existent user");
            verify(userRepository).findByUsername("nonexistent");
        }

        @Test
        @DisplayName("Should return all users")
        void testGetAllUsers() {
            // Arrange
            User user1 = new User();
            user1.setId(1L);
            user1.setUsername("user1");
            user1.setPassword("pass1");

            User user2 = new User();
            user2.setId(2L);
            user2.setUsername("user2");
            user2.setPassword("pass2");

            when(userRepository.findAll()).thenReturn(Arrays.asList(user1, user2));

            // Act
            List<User> users = userService.getAllUsers();

            // Assert
            assertNotNull(users, "Should return non-null list");
            assertEquals(2, users.size(), "Should return exactly 2 users");
            assertEquals("user1", users.get(0).getUsername(), "First user should be user1");
            assertEquals("user2", users.get(1).getUsername(), "Second user should be user2");
            verify(userRepository).findAll();
        }
    }

    /**
     * Test suite for JwtUtil
     */
    @Nested
    @DisplayName("JWT Utility Tests")
    class JwtUtilTests {

        private JwtUtil jwtUtil;
        private static final String SECRET = "MyVeryLongSecretKeyForJwtAuthentication123456789";
        private SecretKey key;

        @BeforeEach
        void setUp() {
            key = Keys.hmacShaKeyFor(SECRET.getBytes());
            jwtUtil = new JwtUtil();
        }

        @Test
        @DisplayName("Should generate valid JWT token")
        void testGenerateToken() {
            // Act
            String token = jwtUtil.generateToken(TEST_USERNAME, "USER");

            // Assert
            assertNotNull(token, "Token should not be null");
            assertTrue(token.startsWith("eyJ"), "Token should be a JWT (starts with eyJ)");

            // Verify we can parse it back
            io.jsonwebtoken.Claims claims = io.jsonwebtoken.Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            assertEquals(TEST_USERNAME, claims.getSubject(), "Token should contain correct username");
            assertEquals("USER", claims.get("role", String.class), "Token should contain correct role");
            assertNotNull(claims.getIssuedAt(), "Token should have issued at timestamp");
            assertNotNull(claims.getExpiration(), "Token should have expiration timestamp");
        }

        @Test
        @DisplayName("Should validate valid token")
        void testValidateTokenValid() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USERNAME)
                    .claim("role", "USER")
                    .signWith(key)
                    .compact();

            // Act
            boolean isValid = jwtUtil.validate(token);

            // Assert
            assertTrue(isValid, "Valid token should pass validation");
        }

        @Test
        @DisplayName("Should reject token with invalid signature")
        void testValidateTokenInvalidSignature() {
            // Arrange
            String wrongSecret = "wrongsecret";
            SecretKey wrongKey = Keys.hmacShaKeyFor(wrongSecret.getBytes());
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USERNAME)
                    .claim("role", "USER")
                    .signWith(wrongKey)
                    .compact();

            // Act
            boolean isValid = jwtUtil.validate(token);

            // Assert
            assertFalse(isValid, "Token with wrong signature should fail validation");
        }

        @Test
        @DisplayName("Should reject expired token")
        void testValidateTokenExpired() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USERNAME)
                    .claim("role", "USER")
                    .expiration(new java.util.Date(System.currentTimeMillis() - 1000)) // Expired 1 second ago
                    .signWith(key)
                    .compact();

            // Act
            boolean isValid = jwtUtil.validate(token);

            // Assert
            assertFalse(isValid, "Expired token should fail validation");
        }

        @Test
        @DisplayName("Should extract username from valid token")
        void testExtractUsername() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USERNAME)
                    .claim("role", "USER")
                    .signWith(key)
                    .compact();

            // Act
            String username = jwtUtil.extractUsername(token);

            // Assert
            assertEquals(TEST_USERNAME, username, "Should extract correct username");
        }

        @Test
        @DisplayName("Should extract role from valid token")
        void testExtractRole() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USERNAME)
                    .claim("role", "USER")
                    .signWith(key)
                    .compact();

            // Act
            String role = jwtUtil.extractRole(token);

            // Assert
            assertEquals("USER", role, "Should extract correct role");
        }

        @Test
        @DisplayName("Should return null for invalid token")
        void testExtractUsernameInvalidToken() {
            // Act
            String username = jwtUtil.extractUsername("invalid.token.here");

            // Assert
            assertNull(username, "Should return null for invalid token");
        }

        @Test
        @DisplayName("Should handle token with no role claim")
        void testExtractRoleMissingClaim() {
            // Arrange
            String token = io.jsonwebtoken.Jwts.builder()
                    .subject(TEST_USERNAME)
                    // No role claim
                    .signWith(key)
                    .compact();

            // Act
            String role = jwtUtil.extractRole(token);

            // Assert
            assertNull(role, "Should return null when role claim is missing");
        }
    }

    /**
     * Test suite for SecurityConfig
     */
    @Nested
    @DisplayName("Security Configuration Tests")
    class SecurityConfigTests {

        @Test
        @DisplayName("Should provide BCrypt password encoder")
        void testPasswordEncoderIsBCrypt() {
            // Act
            PasswordEncoder passwordEncoder = securityConfig.passwordEncoder();

            // Assert
            assertNotNull(passwordEncoder, "Should return password encoder");
            assertTrue(passwordEncoder instanceof org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder,
                    "Should be BCryptPasswordEncoder");
        }

        @Test
        @DisplayName("Should properly encode and match passwords")
        void testPasswordEncodingAndMatching() {
            // Arrange
            when(securityConfig.passwordEncoder()).thenAnswer(invocation -> {
                return new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder();
            });
            PasswordEncoder passwordEncoder = securityConfig.passwordEncoder();
            String rawPassword = "mySecretPassword123!";

            // Act
            String encodedPassword = passwordEncoder.encode(rawPassword);
            boolean matches = passwordEncoder.matches(rawPassword, encodedPassword);
            boolean doesNotMatch = passwordEncoder.matches("wrongPassword", encodedPassword);

            // Assert
            assertNotNull(encodedPassword, "Should return encoded password");
            assertFalse(encodedPassword.equals(rawPassword), "Encoded password should differ from raw");
            assertTrue(matches, "Should match the original password");
            assertFalse(doesNotMatch, "Should not match wrong password");
        }

        @Test
        @DisplayName("Should produce different encodings for same password (due to salt)")
        void testSamePasswordDifferentEncodings() {
            // Arrange
            when(securityConfig.passwordEncoder()).thenAnswer(invocation -> {
                return new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder();
            });
            PasswordEncoder passwordEncoder = securityConfig.passwordEncoder();
            String rawPassword = "samePassword";

            // Act
            String encoded1 = passwordEncoder.encode(rawPassword);
            String encoded2 = passwordEncoder.encode(rawPassword);

            // Assert
            assertNotNull(encoded1, "First encoding should not be null");
            assertNotNull(encoded2, "Second encoding should not be null");
            assertFalse(encoded1.equals(encoded2),
                    "Same password should produce different encodings due to salt");
            // But both should match the original password
            assertTrue(passwordEncoder.matches(rawPassword, encoded1),
                    "First encoding should match original password");
            assertTrue(passwordEncoder.matches(rawPassword, encoded2),
                    "Second encoding should match original password");
        }
    }
}