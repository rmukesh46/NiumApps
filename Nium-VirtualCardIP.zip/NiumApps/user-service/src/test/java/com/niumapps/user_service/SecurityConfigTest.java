package com.niumapps.user_service;

import com.niumapps.user_service.config.SecurityConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SecurityConfigTest {

    @InjectMocks
    private SecurityConfig securityConfig;

    @Test
    void testPasswordEncoderIsBCrypt() {
        // Act
        PasswordEncoder passwordEncoder = securityConfig.passwordEncoder();

        // Assert
        assertNotNull(passwordEncoder);
        assertTrue(passwordEncoder instanceof BCryptPasswordEncoder);
    }

    @Test
    void testPasswordEncodingAndMatching() {
        // Arrange
        PasswordEncoder passwordEncoder = securityConfig.passwordEncoder();
        String rawPassword = "mySecretPassword123!";

        // Act
        String encodedPassword = passwordEncoder.encode(rawPassword);
        boolean matches = passwordEncoder.matches(rawPassword, encodedPassword);
        boolean doesNotMatch = passwordEncoder.matches("wrongPassword", encodedPassword);

        // Assert
        assertNotNull(encodedPassword);
        assertFalse(encodedPassword.equals(rawPassword)); // Should be different
        assertTrue(matches); // Should match the original password
        assertFalse(doesNotMatch); // Should not match wrong password
    }

    @Test
    void testSamePasswordDifferentEncodings() {
        // Arrange
        PasswordEncoder passwordEncoder = securityConfig.passwordEncoder();
        String rawPassword = "samePassword";

        // Act
        String encoded1 = passwordEncoder.encode(rawPassword);
        String encoded2 = passwordEncoder.encode(rawPassword);

        // Assert
        // With BCrypt, same password should produce different encodings due to salt
        assertNotNull(encoded1);
        assertNotNull(encoded2);
        assertFalse(encoded1.equals(encoded2)); // Should be different due to salt
        // But both should match the original password
        assertTrue(passwordEncoder.matches(rawPassword, encoded1));
        assertTrue(passwordEncoder.matches(rawPassword, encoded2));
    }
}