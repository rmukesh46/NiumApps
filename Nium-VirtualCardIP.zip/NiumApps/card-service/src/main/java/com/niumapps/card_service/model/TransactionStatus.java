package com.niumapps.card_service.model;

public enum TransactionStatus {
    SUCCESSFUL,
    DECLINED,
    PENDING
}