package com.niumapps.card_service.model;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Represents a financial transaction on a card.
 * Transactions record all spending and top-up operations on cards.
 *
 * Each transaction is associated with a specific card and includes:
 * - The type of transaction (SPEND or TOP_UP)
 * - The amount of money involved
 * - The status of the transaction (SUCCESSFUL or DECLINED)
 * - Timestamps for when it was created and processed
 *
 * The service uses idempotency keys to ensure that identical transaction
 * requests are not processed more than once, which is critical for
 * financial operations to prevent accidental duplicate charges or credits.
 *
 * Transaction types:
 * - SPEND: Represents a purchase or deduction from the card balance
 * - TOP_UP: Represents adding funds to the card balance
 *
 * Transaction statuses:
 * - PENDING: Initial state when transaction is being processed
 * - SUCCESSFUL: Transaction completed successfully
 * - DECLINED: Transaction was rejected (e.g., insufficient funds, card blocked)
 *
 * Fields:
 * - id: Unique identifier for the transaction (auto-generated)
 * - cardId: Foreign key referencing the card this transaction belongs to
 * - type: Type of transaction (SPEND for purchases, TOP_UP for adding funds)
 * - amount: Monetary value of the transaction (positive for both types)
 * - status: Whether the transaction was successful or declined
 * - createdAt: Timestamp when the transaction was initiated
 */
@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "card_id", nullable = false)
    private Long cardId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionType type;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionStatus status;

    // Constructors
    public Transaction() {
        this.createdAt = LocalDateTime.now();
    }

    public Transaction(Long cardId, TransactionType type, BigDecimal amount) {
        this.cardId = cardId;
        this.type = type;
        this.amount = amount;
        this.status = TransactionStatus.PENDING;
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCardId() {
        return cardId;
    }

    public void setCardId(Long cardId) {
        this.cardId = cardId;
    }

    public TransactionType getType() {
        return type;
    }

    public void setType(TransactionType type) {
        this.type = type;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public TransactionStatus getStatus() {
        return status;
    }

    public void setStatus(TransactionStatus status) {
        this.status = status;
    }
}