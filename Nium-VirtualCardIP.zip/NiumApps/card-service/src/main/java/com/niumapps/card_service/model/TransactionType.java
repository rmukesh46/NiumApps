package com.niumapps.card_service.model;

public enum TransactionType {
    SPEND,
    TOP_UP
}