package com.niumapps.card_service.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class UserServiceClient {

    @Value("${user.service.url:http://localhost:8083}")
    private String userServiceUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public UserDto getUserByUsername(String username) {
        try {
            ResponseEntity<UserDto> response = restTemplate.getForEntity(
                    userServiceUrl + "/user-service/{username}",
                    UserDto.class,
                    username);
            return response.getBody();
        } catch (Exception e) {
            // Log the error in production
            return null;
        }
    }
}