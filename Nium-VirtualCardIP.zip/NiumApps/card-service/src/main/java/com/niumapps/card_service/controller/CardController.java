package com.niumapps.card_service.controller;

import com.niumapps.card_service.model.Card;
import com.niumapps.card_service.model.Transaction;
import com.niumapps.card_service.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

import java.math.BigDecimal;

@RestController
@RequestMapping("/cards")
public class CardController {

    @Autowired
    private CardService cardService;

    /**
     * Create a new card
     * POST /cards
     * Request body: { "cardholderName": "John Doe", "initialBalance": 100.00 }
     */
    @PostMapping
    public ResponseEntity<Card> createCard(HttpServletRequest httpRequest,
                                           @RequestBody CreateCardRequest request) {
        String authorizationHeader = extractAuthTokenFromCookies(httpRequest);
        Card card = cardService.createCard(authorizationHeader, request.getCardholderName(), request.getInitialBalance());
        return new ResponseEntity<>(card, HttpStatus.CREATED);
    }

    /**
     * Spend from a card
     * POST /cards/{cardId}/spend
     * Request body: { "amount": 50.00, "idempotencyKey": "unique-key-123" }
     */
    @PostMapping("/{cardId}/spend")
    public ResponseEntity<Transaction> spendFromCard(HttpServletRequest httpRequest,
                                                     @PathVariable Long cardId,
                                                     @RequestBody SpendRequest request) {
        String authorizationHeader = extractAuthTokenFromCookies(httpRequest);
        Transaction transaction = cardService.spendFromCard(authorizationHeader, cardId, request.getAmount(), request.getIdempotencyKey());
        return new ResponseEntity<>(transaction, HttpStatus.OK);
    }

    /**
     * Top up a card
     * POST /cards/{cardId}/topup
     * Request body: { "amount": 50.00, "idempotencyKey": "unique-key-123" }
     */
    @PostMapping("/{cardId}/topup")
    public ResponseEntity<Transaction> topUpCard(HttpServletRequest httpRequest,
                                                 @PathVariable Long cardId,
                                                 @RequestBody TopUpRequest request) {
        String authorizationHeader = extractAuthTokenFromCookies(httpRequest);
        Transaction transaction = cardService.topUpCard(authorizationHeader, cardId, request.getAmount(), request.getIdempotencyKey());
        return new ResponseEntity<>(transaction, HttpStatus.OK);
    }

    /**
     * Retrieve card details
     * GET /cards/{cardId}
     */
    @GetMapping("/{cardId}")
    public ResponseEntity<Card> getCardDetails(HttpServletRequest httpRequest,
                                               @PathVariable Long cardId) {
        String authorizationHeader = extractAuthTokenFromCookies(httpRequest);
        Card card = cardService.getCardDetails(authorizationHeader, cardId);
        return new ResponseEntity<>(card, HttpStatus.OK);
    }

    /**
     * Retrieve transaction history
     * GET /cards/{cardId}/transactions
     */
    @GetMapping("/{cardId}/transactions")
    public ResponseEntity<java.util.List<Transaction>> getTransactionHistory(HttpServletRequest httpRequest,
                                                                           @PathVariable Long cardId) {
        String authorizationHeader = extractAuthTokenFromCookies(httpRequest);
        java.util.List<Transaction> transactions = cardService.getTransactionHistory(authorizationHeader, cardId);
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }

    /**
     * Block a card
     * POST /cards/{cardId}/block
     */
    @PostMapping("/{cardId}/block")
    public ResponseEntity<Card> blockCard(HttpServletRequest httpRequest,
                                          @PathVariable Long cardId) {
        String authorizationHeader = extractAuthTokenFromCookies(httpRequest);
        Card card = cardService.blockCard(authorizationHeader, cardId);
        return new ResponseEntity<>(card, HttpStatus.OK);
    }

    /**
     * Close a card
     * POST /cards/{cardId}/close
     */
    @PostMapping("/{cardId}/close")
    public ResponseEntity<Card> closeCard(HttpServletRequest httpRequest,
                                          @PathVariable Long cardId) {
        String authorizationHeader = extractAuthTokenFromCookies(httpRequest);
        Card card = cardService.closeCard(authorizationHeader, cardId);
        return new ResponseEntity<>(card, HttpStatus.OK);
    }

    /**
     * Extracts the authentication token from cookies.
     * Looks for a cookie named "jwt_token" containing the JWT token.
     * The token value may or may not include the "Bearer " prefix.
     * @param request the HTTP request
     * @return the authorization header value (Bearer token) or null if not found
     */
    private String extractAuthTokenFromCookies(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("jwt_token".equals(cookie.getName())) {
                    String tokenValue = cookie.getValue();
                    if (tokenValue != null) {
                        // If the token already includes the Bearer prefix, return as-is
                        if (tokenValue.startsWith("Bearer ")) {
                            return tokenValue;
                        }
                        // Otherwise, add the Bearer prefix
                        return "Bearer " + tokenValue;
                    }
                }
            }
        }
        return null;
    }

    // Request body classes
    public static class CreateCardRequest {
        private String cardholderName;
        private BigDecimal initialBalance;

        public String getCardholderName() {
            return cardholderName;
        }

        public void setCardholderName(String cardholderName) {
            this.cardholderName = cardholderName;
        }

        public BigDecimal getInitialBalance() {
            return initialBalance;
        }

        public void setInitialBalance(BigDecimal initialBalance) {
            this.initialBalance = initialBalance;
        }
    }

    public static class SpendRequest {
        private BigDecimal amount;
        private String idempotencyKey;

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }

        public String getIdempotencyKey() {
            return idempotencyKey;
        }

        public void setIdempotencyKey(String idempotencyKey) {
            this.idempotencyKey = idempotencyKey;
        }
    }

    public static class TopUpRequest {
        private BigDecimal amount;
        private String idempotencyKey;

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }

        public String getIdempotencyKey() {
            return idempotencyKey;
        }

        public void setIdempotencyKey(String idempotencyKey) {
            this.idempotencyKey = idempotencyKey;
        }
    }
}