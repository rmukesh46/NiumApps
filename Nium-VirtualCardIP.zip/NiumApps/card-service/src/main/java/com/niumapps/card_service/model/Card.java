package com.niumapps.card_service.model;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Represents a payment card in the system.
 * Cards are associated with users and can be used for spending and topping up funds.
 *
 * The card service supports the following operations:
 * - Creating new cards with an initial balance
 * - Spending funds from cards (decreasing balance)
 * - Topping up cards with additional funds (increasing balance)
 * - Blocking cards (prevents all transactions)
 * - Closing cards (permanently disables the card)
 *
 * Transactions are recorded for audit trail and idempotency keys prevent
 * duplicate processing of the same transaction request.
 *
 * Fields:
 * - id: Unique identifier for the card (auto-generated)
 * - cardholderName: Name of the cardholder
 * - balance: Current monetary balance on the card (precision 19, scale 2)
 * - status: Current status of the card (ACTIVE, BLOCKED, CLOSED)
 * - username: Username of the user who owns this card (immutable after creation)
 * - createdAt: Timestamp when the card was created
 */
@Entity
@Table(name = "cards")
public class Card {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String cardholderName;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal balance;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CardStatus status;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private String username;

    // Constructors
    public Card() {
        this.createdAt = LocalDateTime.now();
    }

    public Card(String cardholderName, BigDecimal balance, String username) {
        this.cardholderName = cardholderName;
        this.balance = balance;
        this.status = CardStatus.ACTIVE;
        this.createdAt = LocalDateTime.now();
        this.username = username;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCardholderName() {
        return cardholderName;
    }

    public void setCardholderName(String cardholderName) {
        this.cardholderName = cardholderName;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public CardStatus getStatus() {
        return status;
    }

    public void setStatus(CardStatus status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}