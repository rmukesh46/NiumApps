package com.niumapps.card_service.model;

public enum CardStatus {
    ACTIVE,
    BLOCKED,
    CLOSED
}