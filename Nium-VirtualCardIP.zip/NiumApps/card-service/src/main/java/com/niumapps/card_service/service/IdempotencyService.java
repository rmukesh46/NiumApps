package com.niumapps.card_service.service;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.UUID;

/**
 * Simple idempotency service for demonstration purposes.
 * In a production system, this would use a persistent store like Redis or database.
 */
@Service
public class IdempotencyService {

    // Using ConcurrentHashMap for thread-safe operations
    // In production, use Redis or database with TTL
    private final Map<String, String> processedKeys = new ConcurrentHashMap<>();

    /**
     * Check if an idempotency key has been processed
     * @param key the idempotency key
     * @return true if key has been processed, false otherwise
     */
    public boolean isProcessed(String key) {
        return processedKeys.containsKey(key);
    }

    /**
     * Mark an idempotency key as processed
     * @param key the idempotency key
     * @param resultId identifier of the result (e.g., transaction ID)
     */
    public void markAsProcessed(String key, String resultId) {
        processedKeys.put(key, resultId);
    }

    /**
     * Get the result ID for a processed idempotency key
     * @param key the idempotency key
     * @return result ID if key was processed, null otherwise
     */
    public String getResultId(String key) {
        return processedKeys.get(key);
    }

    /**
     * Generate a random idempotency key
     * @return random UUID string
     */
    static String generateIdempotencyKey() {
        return UUID.randomUUID().toString();
    }
}