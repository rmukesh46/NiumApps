package com.niumapps.card_service.repository;

import com.niumapps.card_service.model.Card;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CardRepository extends JpaRepository<Card, Long> {
    Optional<Card> findById(Long id);

    Optional<Card> findByIdAndUsername(Long id, String username);
}