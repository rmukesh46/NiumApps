package com.niumapps.card_service.service;

import com.niumapps.card_service.model.Card;
import com.niumapps.card_service.model.CardStatus;
import com.niumapps.card_service.model.Transaction;
import com.niumapps.card_service.model.TransactionStatus;
import com.niumapps.card_service.repository.CardRepository;
import com.niumapps.card_service.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Service layer for card management operations.
 * Handles all financial transactions related to payment cards including:
 * - Card creation with initial balance
 * - Spending funds from cards (decreasing balance)
 * - Topping up cards with additional funds (increasing balance)
 * - Retrieving card details and transaction history
 * - Blocking and closing cards for security
 *
 * This service ensures data consistency through:
 * - Transactional annotations on methods that modify state
 * - Idempotency keys to prevent duplicate transaction processing
 * - User authentication and authorization checks
 * - Balance validation to prevent overdrafts
 *
 * All methods validate that the authenticated user owns the card
 * they are attempting to access or modify.
 *
 * Dependencies:
 * - CardRepository: For persisting and retrieving card entities
 * - TransactionRepository: For persisting and retrieving transaction entities
 * - IdempotencyService: For ensuring idempotent transaction processing
 * - AuthService: For extracting user identity from JWT tokens
 */
@Service
public class CardService {

    @Autowired
    private CardRepository cardRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private IdempotencyService idempotencyService;

    @Autowired
    private AuthService authService;

    /**
     * Extracts the current username from the authorization header
     * @param authorizationHeader The Authorization header value
     * @return Username
     * @throws IllegalStateException if token is invalid or user not found
     */
    private String getCurrentUsername(String authorizationHeader) {
        String username = authService.getCurrentUsername(authorizationHeader);
        if (username == null) {
            throw new IllegalStateException("Invalid or missing authentication token");
        }
        return username;
    }

    /**
     * Create a new card with cardholder name and initial balance
     * @param authorizationHeader The Authorization header containing JWT token
     * @param cardholderName name of the cardholder
     * @param initialBalance initial balance for the card
     * @return created card
     * @throws IllegalStateException if authentication token is invalid
     * @throws IllegalArgumentException if initial balance is negative
     */
    @Transactional
    public Card createCard(String authorizationHeader, String cardholderName, BigDecimal initialBalance) {
        String username = getCurrentUsername(authorizationHeader);
        if (username == null) {
            throw new IllegalStateException("Invalid or missing authentication token");
        }

        if (initialBalance.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Initial balance cannot be negative");
        }

        Card card = new Card(cardholderName, initialBalance, username);
        Card savedCard = cardRepository.save(card);

        // Create initial transaction for the card creation if initial balance > 0
        if (initialBalance.compareTo(BigDecimal.ZERO) > 0) {
            Transaction initialTransaction = new Transaction(
                savedCard.getId(),
                com.niumapps.card_service.model.TransactionType.TOP_UP,
                initialBalance
            );
            initialTransaction.setStatus(TransactionStatus.SUCCESSFUL);
            transactionRepository.save(initialTransaction);
        }

        return savedCard;
    }

    /**
     * Spend from a card (deduct amount)
     * @param authorizationHeader The Authorization header containing JWT token
     * @param cardId ID of the card
     * @param amount amount to spend
     * @param idempotencyKey unique key to ensure idempotency
     * @return transaction result
     * @throws IllegalStateException if authentication token is invalid or card is not active
     * @throws IllegalArgumentException if card not found, amount is invalid, or insufficient funds
     */
    @Transactional
    public Transaction spendFromCard(String authorizationHeader, Long cardId, BigDecimal amount, String idempotencyKey) {
        String username = getCurrentUsername(authorizationHeader);
        if (username == null) {
            throw new IllegalStateException("Invalid or missing authentication token");
        }

        // Check idempotency - if key already processed, return previous result
        if (idempotencyService.isProcessed(idempotencyKey)) {
            String previousTransactionId = idempotencyService.getResultId(idempotencyKey);
            if (previousTransactionId != null) {
                return transactionRepository.findById(Long.valueOf(previousTransactionId))
                        .orElseGet(() -> {
                            // If transaction not found, fall through to create new one
                            // This handles edge cases where record was cleaned up
                            return processSpend(cardId, amount, idempotencyKey, username);
                        });
            }
        }

        // Process the spend operation
        Transaction transaction = processSpend(cardId, amount, idempotencyKey, username);

        // Mark as processed
        idempotencyService.markAsProcessed(idempotencyKey, String.valueOf(transaction.getId()));

        return transaction;
    }

    /**
     * Internal method to process spend operation
     */
    private Transaction processSpend(Long cardId, BigDecimal amount, String idempotencyKey, String username) {
        Card card = cardRepository.findById(cardId)
                .orElseThrow(() -> new IllegalArgumentException("Card not found"));

        // Verify card belongs to current user
        if (!Objects.equals(card.getUsername(), username)) {
            throw new IllegalArgumentException("Card not found or access denied");
        }

        if (!card.getStatus().equals(CardStatus.ACTIVE)) {
            throw new IllegalStateException("Card is not active");
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }

        if (card.getBalance().compareTo(amount) < 0) {
            // Insufficient funds
            Transaction declinedTransaction = new Transaction(cardId,
                    com.niumapps.card_service.model.TransactionType.SPEND, amount);
            declinedTransaction.setStatus(com.niumapps.card_service.model.TransactionStatus.DECLINED);
            return transactionRepository.save(declinedTransaction);
        }

        // Deduct amount from balance
        card.setBalance(card.getBalance().subtract(amount));
        cardRepository.save(card);

        // Create successful transaction
        Transaction transaction = new Transaction(cardId,
                com.niumapps.card_service.model.TransactionType.SPEND, amount);
        transaction.setStatus(TransactionStatus.SUCCESSFUL);
        return transactionRepository.save(transaction);
    }

    /**
     * Top up a card (add funds)
     * @param authorizationHeader The Authorization header containing JWT token
     * @param cardId ID of the card
     * @param amount amount to add
     * @param idempotencyKey unique key to ensure idempotency
     * @return transaction result
     * @throws IllegalStateException if authentication token is invalid or card is not active
     * @throws IllegalArgumentException if card not found or amount is invalid
     */
    @Transactional
    public Transaction topUpCard(String authorizationHeader, Long cardId, BigDecimal amount, String idempotencyKey) {
        String username = getCurrentUsername(authorizationHeader);
        if (username == null) {
            throw new IllegalStateException("Invalid or missing authentication token");
        }

        // Check idempotency - if key already processed, return previous result
        if (idempotencyService.isProcessed(idempotencyKey)) {
            String previousTransactionId = idempotencyService.getResultId(idempotencyKey);
            if (previousTransactionId != null) {
                return transactionRepository.findById(Long.valueOf(previousTransactionId))
                        .orElseGet(() -> {
                            // If transaction not found, fall through to create new one
                            // This handles edge cases where record was cleaned up
                            return processTopUp(cardId, amount, idempotencyKey, username);
                        });
            }
        }

        // Process the top up operation
        Transaction transaction = processTopUp(cardId, amount, idempotencyKey, username);

        // Mark as processed
        idempotencyService.markAsProcessed(idempotencyKey, String.valueOf(transaction.getId()));

        return transaction;
    }

    /**
     * Internal method to process top up operation
     */
    private Transaction processTopUp(Long cardId, BigDecimal amount, String idempotencyKey, String username) {
        Card card = cardRepository.findById(cardId)
                .orElseThrow(() -> new IllegalArgumentException("Card not found"));

        // Verify card belongs to current user
        if (!Objects.equals(card.getUsername(), username)) {
            throw new IllegalArgumentException("Card not found or access denied");
        }

        if (!card.getStatus().equals(CardStatus.ACTIVE)) {
            throw new IllegalStateException("Card is not active");
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }

        // Add amount to balance
        card.setBalance(card.getBalance().add(amount));
        cardRepository.save(card);

        // Create successful transaction
        Transaction transaction = new Transaction(cardId,
                com.niumapps.card_service.model.TransactionType.TOP_UP, amount);
        transaction.setStatus(TransactionStatus.SUCCESSFUL);
        return transactionRepository.save(transaction);
    }

    /**
     * Retrieve card details
     * @param authorizationHeader The Authorization header containing JWT token
     * @param cardId ID of the card
     * @return card details
     * @throws IllegalStateException if authentication token is invalid
     * @throws IllegalArgumentException if card not found or access denied
     */
    public Card getCardDetails(String authorizationHeader, Long cardId) {
        String username = getCurrentUsername(authorizationHeader);
        if (username == null) {
            throw new IllegalStateException("Invalid or missing authentication token");
        }

        return cardRepository.findByIdAndUsername(cardId, username)
                .orElseThrow(() -> new IllegalArgumentException("Card not found or access denied"));
    }

    /**
     * Retrieve transaction history for a card
     * @param authorizationHeader The Authorization header containing JWT token
     * @param cardId ID of the card
     * @return list of transactions
     * @throws IllegalStateException if authentication token is invalid
     * @throws IllegalArgumentException if card not found or access denied
     */
    public List<Transaction> getTransactionHistory(String authorizationHeader, Long cardId) {
        String username = getCurrentUsername(authorizationHeader);
        if (username == null) {
            throw new IllegalStateException("Invalid or missing authentication token");
        }

        // Verify card exists and belongs to current user
        Card card = cardRepository.findByIdAndUsername(cardId, username)
                .orElseThrow(() -> new IllegalArgumentException("Card not found or access denied"));

        return transactionRepository.findByCardId(cardId);
    }

    /**
     * Block a card
     * @param authorizationHeader The Authorization header containing JWT token
     * @param cardId ID of the card
     * @return updated card
     * @throws IllegalStateException if authentication token is invalid
     * @throws IllegalArgumentException if card not found or access denied
     */
    @Transactional
    public Card blockCard(String authorizationHeader, Long cardId) {
        String username = getCurrentUsername(authorizationHeader);
        if (username == null) {
            throw new IllegalStateException("Invalid or missing authentication token");
        }

        Card card = cardRepository.findByIdAndUsername(cardId, username)
                .orElseThrow(() -> new IllegalArgumentException("Card not found or access denied"));

        card.setStatus(CardStatus.BLOCKED);
        return cardRepository.save(card);
    }

    /**
     * Close a card
     * @param authorizationHeader The Authorization header containing JWT token
     * @param cardId ID of the card
     * @return updated card
     * @throws IllegalStateException if authentication token is invalid
     * @throws IllegalArgumentException if card not found or access denied
     */
    @Transactional
    public Card closeCard(String authorizationHeader, Long cardId) {
        String username = getCurrentUsername(authorizationHeader);
        if (username == null) {
            throw new IllegalStateException("Invalid or missing authentication token");
        }

        Card card = cardRepository.findByIdAndUsername(cardId, username)
                .orElseThrow(() -> new IllegalArgumentException("Card not found or access denied"));

        card.setStatus(CardStatus.CLOSED);
        return cardRepository.save(card);
    }
}