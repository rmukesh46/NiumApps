package com.niumapps.card_service.service;

import com.niumapps.card_service.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private JwtUtil jwtUtil;

    /**
     * Extracts the username from the JWT token in the Authorization header
     * @param authorizationHeader The Authorization header value (e.g., "Bearer token")
     * @return Username if token is valid, null otherwise
     */
    public String getCurrentUsername(String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            return null;
        }

        String token = authorizationHeader.substring(7); // Remove "Bearer " prefix

        if (!jwtUtil.validate(token)) {
            return null;
        }

        return jwtUtil.extractUsername(token);
    }
}