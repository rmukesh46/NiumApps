package com.niumapps.card_service;

import com.niumapps.card_service.model.Card;
import com.niumapps.card_service.model.Transaction;
import com.niumapps.card_service.model.TransactionStatus;
import com.niumapps.card_service.repository.CardRepository;
import com.niumapps.card_service.repository.TransactionRepository;
import com.niumapps.card_service.service.CardService;
import com.niumapps.card_service.service.IdempotencyService;
import com.niumapps.card_service.service.AuthService;
import com.niumapps.card_service.util.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CardServiceApplicationTests {

    @InjectMocks
    private CardService cardService;


    @Mock
    private CardRepository cardRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private IdempotencyService idempotencyService;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private AuthService authService;


    // In-memory storage for cards, transactions, and idempotency keys to mimic repository behavior
    private final Map<Long, Card> cards = new HashMap<>();
    private final Map<Long, Transaction> transactions = new HashMap<>();
    private final Map<String, String> idempotencyResults = new HashMap<>();
    private Long cardIdSequence = 1L;
    private Long transactionIdSequence = 1L;
    private Long testCardId;

    private String createValidToken(String username) {
        // This uses the same secret as in JwtUtil
        String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
        return Jwts.builder()
                .setSubject(username)
                .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .compact();
    }

    @BeforeEach
    void setUp() {
        // Clear storage before each test
        cards.clear();
        transactions.clear();
        idempotencyResults.clear();
        cardIdSequence = 1L;
        transactionIdSequence = 1L;



        // Mock the auth service to use the real implementation (which will use our mocks)
        // We don't mock getCurrentUserId so that it uses the real AuthService logic
        // which will call our mocked jwtUtil and userServiceClient

        // Mock the IdempotencyService with stateful behavior
        when(idempotencyService.isProcessed(anyString())).thenAnswer(invocation -> {
            String key = invocation.getArgument(0);
            return idempotencyResults.containsKey(key);
        });
        when(idempotencyService.getResultId(anyString())).thenAnswer(invocation -> {
            String key = invocation.getArgument(0);
            return idempotencyResults.get(key);
        });
        doAnswer(invocation -> {
            String key = invocation.getArgument(0);
            String resultId = invocation.getArgument(1);
            idempotencyResults.put(key, resultId);
            return null;
        }).when(idempotencyService).markAsProcessed(anyString(), anyString());
// Mock the JwtUtil to validate tokens and extract usernames
        when(jwtUtil.validate(anyString())).thenReturn(true);
        when(jwtUtil.extractUsername(anyString())).thenAnswer(invocation -> {
            String token = invocation.getArgument(0);
            System.out.println("extractUsername called with token: " + token);
            // Extract username from token without validation (since we assume it's valid)
            String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
            try {
                Claims claims = Jwts.parser()
                        .verifyWith(Keys.hmacShaKeyFor(secret.getBytes()))
                        .build()
                        .parseSignedClaims(token)
                        .getPayload();
                String subject = claims.getSubject();
                System.out.println("extractUsername returning: " + subject);
                return subject;
            } catch (Exception e) {
                System.out.println("extractUsername exception: " + e.getMessage());
                return null;
            }
        });

        // Mock the auth service to return the username from the token
        when(authService.getCurrentUsername(anyString())).thenAnswer(invocation -> {
            String authHeader = invocation.getArgument(0);
            System.out.println("authService.getCurrentUsername called with: " + authHeader);
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7); // Remove "Bearer "
                System.out.println("token extracted: " + token);
                boolean isValid = jwtUtil.validate(token);
                System.out.println("token validation result: " + isValid);
                if (isValid) {
                    String username = jwtUtil.extractUsername(token);
                    System.out.println("username extracted: " + username);
                    return username;
                }
            }
            System.out.println("returning null from authService");
            return null;
        });

        // Mock the card repository with essential methods
        when(cardRepository.save(any(Card.class))).thenAnswer(invocation -> {
            System.out.println("cardRepository.save called");
            Card card = invocation.getArgument(0);
            if (card.getId() == null) {
                card.setId(cardIdSequence++);
            }
            cards.put(card.getId(), card);
            return card;
        });
        when(cardRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return java.util.Optional.ofNullable(cards.get(id));
        });
        when(cardRepository.findByIdAndUsername(anyLong(), anyString())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            String username = invocation.getArgument(1);
            Card card = cards.get(id);
            if (card != null && Objects.equals(card.getUsername(), username)) {
                return java.util.Optional.of(card);
            }
            return java.util.Optional.empty();
        });

        // Mock the transaction repository with essential methods
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> {
            Transaction transaction = invocation.getArgument(0);
            if (transaction.getId() == null) {
                transaction.setId(transactionIdSequence++);
            }
            transactions.put(transaction.getId(), transaction);
            return transaction;
        });
        when(transactionRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return java.util.Optional.ofNullable(transactions.get(id));
        });
        when(transactionRepository.findByCardId(anyLong())).thenAnswer(invocation -> {
            Long cardId = invocation.getArgument(0);
            return transactions.values().stream()
                    .filter(t -> Objects.equals(t.getCardId(), cardId))
                    .collect(Collectors.toList());
        });

        // Create a test card before each test
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        System.out.println("authHeader in setUp: " + authHeader);
        Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
        testCardId = card.getId();
    }

    @Test
    void testCreateCard() {
        System.out.println("Starting testCreateCard");
        String token = createValidToken("johndoe");
        String authHeader = "Bearer " + token;
        System.out.println("authHeader: " + authHeader);
        Card card = cardService.createCard(authHeader, "John Doe", new BigDecimal("50.00"));
        System.out.println("card created: " + card);

        assertNotNull(card.getId());
        assertEquals("John Doe", card.getCardholderName());
        assertEquals(new BigDecimal("50.00"), card.getBalance());
        assertEquals(com.niumapps.card_service.model.CardStatus.ACTIVE, card.getStatus());
    }

    @Test
    void testGetCardDetails() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        Card card = cardService.getCardDetails(authHeader, testCardId);

        assertNotNull(card);
        assertEquals(testCardId, card.getId());
        assertEquals("Test User", card.getCardholderName());
        assertEquals(new BigDecimal("100.00"), card.getBalance());
    }

    @Test
    void testSpendFromCardSuccess() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        Transaction transaction = cardService.spendFromCard(authHeader, testCardId, new BigDecimal("30.00"), "spend-1");

        assertNotNull(transaction.getId());
        assertEquals(testCardId, transaction.getCardId());
        assertEquals(com.niumapps.card_service.model.TransactionType.SPEND, transaction.getType());
        assertEquals(new BigDecimal("30.00"), transaction.getAmount());
        assertEquals(TransactionStatus.SUCCESSFUL, transaction.getStatus());

        // Verify card balance decreased
        Card updatedCard = cardService.getCardDetails(authHeader, testCardId);
        assertEquals(new BigDecimal("70.00"), updatedCard.getBalance());
    }

    @Test
    void testSpendFromCardIdempotency() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        // First request
        Transaction firstTransaction = cardService.spendFromCard(authHeader, testCardId, new BigDecimal("20.00"), "idempotent-key");

        // Second request with same idempotency key should return same transaction
        Transaction secondTransaction = cardService.spendFromCard(authHeader, testCardId, new BigDecimal("20.00"), "idempotent-key");

        // Should be the same transaction
        assertEquals(firstTransaction.getId(), secondTransaction.getId());
        assertEquals(firstTransaction.getAmount(), secondTransaction.getAmount());
        assertEquals(firstTransaction.getStatus(), secondTransaction.getStatus());

        // Card balance should only be decreased once (by 20, not 40)
        Card card = cardService.getCardDetails(authHeader, testCardId);
        assertEquals(new BigDecimal("80.00"), card.getBalance()); // Started with 100, spent 20
    }

    @Test
    void testSpendFromCardInsufficientFunds() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        Transaction transaction = cardService.spendFromCard(authHeader, testCardId, new BigDecimal("150.00"), "spend-2");

        assertNotNull(transaction.getId());
        assertEquals(testCardId, transaction.getCardId());
        assertEquals(com.niumapps.card_service.model.TransactionType.SPEND, transaction.getType());
        assertEquals(new BigDecimal("150.00"), transaction.getAmount());
        assertEquals(TransactionStatus.DECLINED, transaction.getStatus());

        // Verify card balance unchanged
        Card updatedCard = cardService.getCardDetails(authHeader, testCardId);
        assertEquals(new BigDecimal("100.00"), updatedCard.getBalance());
    }

    @Test
    void testTopUpCard() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        Transaction transaction = cardService.topUpCard(authHeader, testCardId, new BigDecimal("50.00"), "topup-1");

        assertNotNull(transaction.getId());
        assertEquals(testCardId, transaction.getCardId());
        assertEquals(com.niumapps.card_service.model.TransactionType.TOP_UP, transaction.getType());
        assertEquals(new BigDecimal("50.00"), transaction.getAmount());
        assertEquals(TransactionStatus.SUCCESSFUL, transaction.getStatus());

        // Verify card balance increased
        Card updatedCard = cardService.getCardDetails(authHeader, testCardId);
        assertEquals(new BigDecimal("150.00"), updatedCard.getBalance());
    }

    @Test
    void testTopUpCardIdempotency() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        // First request
        Transaction firstTransaction = cardService.topUpCard(authHeader, testCardId, new BigDecimal("25.00"), "topup-idempotent-key");

        // Second request with same idempotency key should return same transaction
        Transaction secondTransaction = cardService.topUpCard(authHeader, testCardId, new BigDecimal("25.00"), "topup-idempotent-key");

        // Should be the same transaction
        assertEquals(firstTransaction.getId(), secondTransaction.getId());
        assertEquals(firstTransaction.getAmount(), secondTransaction.getAmount());
        assertEquals(firstTransaction.getStatus(), secondTransaction.getStatus());

        // Card balance should only be increased once (by 25, not 50)
        Card card = cardService.getCardDetails(authHeader, testCardId);
        assertEquals(new BigDecimal("125.00"), card.getBalance()); // Started with 100, added 25
    }

    @Test
    void testGetTransactionHistory() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        // Perform some transactions
        cardService.spendFromCard(authHeader, testCardId, new BigDecimal("20.00"), "txn-1");
        cardService.topUpCard(authHeader, testCardId, new BigDecimal("30.00"), "txn-2");

        List<Transaction> transactions = cardService.getTransactionHistory(authHeader, testCardId);

        // Should have initial top-up (from card creation) + spend + top-up = 3 transactions
        assertEquals(3, transactions.size());

        // Verify we have both spend and top-up transactions
        long spendCount = transactions.stream()
                .filter(t -> t.getType() == com.niumapps.card_service.model.TransactionType.SPEND)
                .count();
        long topUpCount = transactions.stream()
                .filter(t -> t.getType() == com.niumapps.card_service.model.TransactionType.TOP_UP)
                .count();

        assertEquals(1, spendCount);
        assertEquals(2, topUpCount); // Initial + manual top-up
    }

    @Test
    void testCardStatusRestrictions() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        // Block the card
        cardService.blockCard(authHeader, testCardId);

        // Try to spend from blocked card - should throw exception
        assertThrows(IllegalStateException.class, () -> {
            cardService.spendFromCard(authHeader, testCardId, new BigDecimal("10.00"), "spend-blocked");
        });

        // Try to top up blocked card - should throw exception
        assertThrows(IllegalStateException.class, () -> {
            cardService.topUpCard(authHeader, testCardId, new BigDecimal("10.00"), "topup-blocked");
        });
    }

    @Test
    void testCreateCardWithNegativeInitialBalance() {
        String token = createValidToken("negativeuser");
        String authHeader = "Bearer " + token;
        assertThrows(IllegalArgumentException.class, () -> {
            cardService.createCard(authHeader, "Negative User", new BigDecimal("-10.00"));
        });
    }

    @Test
    void testSpendWithNegativeAmount() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        assertThrows(IllegalArgumentException.class, () -> {
            cardService.spendFromCard(authHeader, testCardId, new BigDecimal("-10.00"), "spend-negative");
        });
    }

    @Test
    void testTopUpWithNegativeAmount() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        assertThrows(IllegalArgumentException.class, () -> {
            cardService.topUpCard(authHeader, testCardId, new BigDecimal("-10.00"), "topup-negative");
        });
    }
}