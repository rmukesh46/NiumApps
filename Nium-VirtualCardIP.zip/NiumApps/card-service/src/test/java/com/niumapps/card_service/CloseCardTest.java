package com.niumapps.card_service;

import com.niumapps.card_service.model.Card;
import com.niumapps.card_service.model.CardStatus;
import com.niumapps.card_service.repository.CardRepository;
import com.niumapps.card_service.repository.TransactionRepository;
import com.niumapps.card_service.service.CardService;
import com.niumapps.card_service.service.IdempotencyService;
import com.niumapps.card_service.service.AuthService;
import com.niumapps.card_service.util.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CloseCardTest {

    @InjectMocks
    private CardService cardService;

    @Mock
    private CardRepository cardRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private IdempotencyService idempotencyService;

    @Mock
    private AuthService authService;

    @Mock
    private JwtUtil jwtUtil;

    private Long testCardId;

    private String createValidToken(String username) {
        // This uses the same secret as in JwtUtil
        String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
        return Jwts.builder()
                .setSubject(username)
                .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .compact();
    }

    @BeforeEach
    void setUp() {
        // Mock the auth service to return the username from the token
        when(authService.getCurrentUsername(anyString())).thenAnswer(invocation -> {
            String authHeader = invocation.getArgument(0);
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7); // Remove "Bearer "
                if (jwtUtil.validate(token)) {
                    return jwtUtil.extractUsername(token);
                }
            }
            return null;
        });

        // Mock the JwtUtil to validate tokens and extract usernames
        when(jwtUtil.validate(anyString())).thenReturn(true);
        when(jwtUtil.extractUsername(anyString())).thenAnswer(invocation -> {
            String token = invocation.getArgument(0);
            String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
            try {
                Claims claims = Jwts.parser()
                        .verifyWith(Keys.hmacShaKeyFor(secret.getBytes()))
                        .build()
                        .parseSignedClaims(token)
                        .getPayload();
                return claims.getSubject();
            } catch (Exception e) {
                return null;
            }
        });

        // Mock the card repository
        when(cardRepository.save(any(Card.class))).thenAnswer(invocation -> {
            Card card = invocation.getArgument(0);
            if (card.getId() == null) {
                card.setId(1L);
            }
            return card;
        });
        when(cardRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return java.util.Optional.ofNullable(new Card());
        });
        when(cardRepository.findByIdAndUsername(anyLong(), anyString())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            String username = invocation.getArgument(1);
            Card card = new Card();
            card.setId(id);
            card.setUsername(username);
            if (card != null && Objects.equals(card.getUsername(), username)) {
                return java.util.Optional.of(card);
            }
            return java.util.Optional.empty();
        });

        // Create a test card before each test
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
        testCardId = card.getId();
    }

    @Test
    void testCloseCardSuccess() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        Card closedCard = cardService.closeCard(authHeader, testCardId);

        assertNotNull(closedCard);
        assertEquals(CardStatus.CLOSED, closedCard.getStatus());
    }

    @Test
    void testCloseCardUnauthenticated() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Make authService return null (invalid token)
        when(authService.getCurrentUsername(anyString())).thenReturn(null);

        assertThrows(IllegalStateException.class, () -> {
            cardService.closeCard(authHeader, testCardId);
        });
    }

    @Test
    void testCloseCardNotFound() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Make cardRepository return empty optional
        when(cardRepository.findByIdAndUsername(anyLong(), anyString())).thenReturn(java.util.Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> {
            cardService.closeCard(authHeader, testCardId);
        });
    }

    @Test
    void testCloseCardWrongUser() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Make cardRepository return a card with different username
        Card otherUserCard = new Card();
        otherUserCard.setId(testCardId);
        otherUserCard.setUsername("otheruser");
        when(cardRepository.findByIdAndUsername(testCardId, "testuser")).thenReturn(java.util.Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> {
            cardService.closeCard(authHeader, testCardId);
        });
    }
}