package com.niumapps.card_service;

import com.niumapps.card_service.model.Card;
import com.niumapps.card_service.model.Transaction;
import com.niumapps.card_service.repository.CardRepository;
import com.niumapps.card_service.repository.TransactionRepository;
import com.niumapps.card_service.service.CardService;
import com.niumapps.card_service.service.IdempotencyService;
import com.niumapps.card_service.service.AuthService;
import com.niumapps.card_service.util.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SetupTest {

    @InjectMocks
    private CardService cardService;

    @Mock
    private CardRepository cardRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private IdempotencyService idempotencyService;

    @Mock
    private AuthService authService;

    @Mock
    private JwtUtil jwtUtil;

    private Long testCardId;

    private String createValidToken(String username) {
        // This uses the same secret as in JwtUtil
        String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
        return Jwts.builder()
                .setSubject(username)
                .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .compact();
    }

    @BeforeEach
    void setUp() {
        System.out.println("Starting setUp");

        // Create test tokens
        String testuserToken = createValidToken("testuser");
        String johndoeToken = createValidToken("johndoe");

        // Mock the JwtUtil to validate tokens and extract usernames
        when(jwtUtil.validate(testuserToken)).thenReturn(true);
        when(jwtUtil.validate(johndoeToken)).thenReturn(true);
        when(jwtUtil.extractUsername(testuserToken)).thenReturn("testuser");
        when(jwtUtil.extractUsername(johndoeToken)).thenReturn("johndoe");

        // Mock the auth service to return the username from the token
        when(authService.getCurrentUsername(anyString())).thenAnswer(invocation -> {
            String authHeader = invocation.getArgument(0);
            System.out.println("authService.getCurrentUsername called with: " + authHeader);
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7); // Remove "Bearer "
                System.out.println("token extracted: " + token);
                // Note: We're not actually validating here since we're relying on the mock
                // In a real test, we might want to call jwtUtil.validate(token) but we've stubbed it
                if (token.equals(testuserToken)) {
                    System.out.println("username extracted: testuser");
                    return "testuser";
                } else if (token.equals(johndoeToken)) {
                    System.out.println("username extracted: johndoe");
                    return "johndoe";
                }
            }
            System.out.println("returning null from authService");
            return null;
        });

        // Mock the card repository with essential methods
        when(cardRepository.save(any(Card.class))).thenAnswer(invocation -> {
            System.out.println("cardRepository.save called");
            Card card = invocation.getArgument(0);
            if (card.getId() == null) {
                card.setId(1L);
            }
            return card;
        });
        when(cardRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return java.util.Optional.ofNullable(new Card());
        });
        when(cardRepository.findByIdAndUsername(anyLong(), anyString())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            String username = invocation.getArgument(1);
            Card card = new Card();
            card.setId(id);
            card.setUsername(username);
            if (card != null && Objects.equals(card.getUsername(), username)) {
                return java.util.Optional.of(card);
            }
            return java.util.Optional.empty();
        });

        // Mock the transaction repository with essential methods
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> {
            Transaction transaction = invocation.getArgument(0);
            if (transaction.getId() == null) {
                transaction.setId(1L);
            }
            return transaction;
        });
        when(transactionRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return java.util.Optional.ofNullable(new Transaction());
        });
        when(transactionRepository.findByCardId(anyLong())).thenAnswer(invocation -> {
            Long cardId = invocation.getArgument(0);
            return java.util.List.of(new Transaction());
        });

        System.out.println("About to create test card");
        // Create a test card before each test
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        System.out.println("authHeader in setUp: " + authHeader);
        Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
        System.out.println("card created: " + card);
        testCardId = card.getId();
        System.out.println("testCardId: " + testCardId);
    }

    @Test
    void testSetupWorks() {
        System.out.println("In test method");
        assertNotNull(testCardId);
    }
}