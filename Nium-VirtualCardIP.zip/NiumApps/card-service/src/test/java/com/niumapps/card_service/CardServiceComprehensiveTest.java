package com.niumapps.card_service;

import com.niumapps.card_service.model.Card;
import com.niumapps.card_service.model.CardStatus;
import com.niumapps.card_service.model.Transaction;
import com.niumapps.card_service.model.TransactionStatus;
import com.niumapps.card_service.model.TransactionType;
import com.niumapps.card_service.repository.CardRepository;
import com.niumapps.card_service.repository.TransactionRepository;
import com.niumapps.card_service.service.CardService;
import com.niumapps.card_service.service.IdempotencyService;
import com.niumapps.card_service.service.AuthService;
import com.niumapps.card_service.util.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Comprehensive unit tests for the Card Service.
 * Covers all major functionalities: card creation, spending, topping up,
 * idempotency, status management, and edge cases.
 */
@ExtendWith(MockitoExtension.class)
class CardServiceComprehensiveTest {

    // Mocks
    @Mock
    private CardRepository cardRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private IdempotencyService idempotencyService;

    @Mock
    private AuthService authService;

    @Mock
    private JwtUtil jwtUtil;

    // Inject mocks into service
    @InjectMocks
    private CardService cardService;

    // Test data
    private Long testCardId;
    private final String TEST_USERNAME = "testuser";
    private final String OTHER_USERNAME = "otheruser";
    private final String TEST_TOKEN_PREFIX = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9";
    private final String TEST_SECRET = "MyVeryLongSecretKeyForJwtAuthentication123456789";

    @BeforeEach
    void setUp() {
        // Create test tokens for different users
        String testuserToken = Jwts.builder()
                .setSubject(TEST_USERNAME)
                .signWith(Keys.hmacShaKeyFor(TEST_SECRET.getBytes()))
                .compact();

        String otheruserToken = Jwts.builder()
                .setSubject(OTHER_USERNAME)
                .signWith(Keys.hmacShaKeyFor(TEST_SECRET.getBytes()))
                .compact();

        // Mock JwtUtil
        when(jwtUtil.validate(anyString())).thenReturn(true);
        when(jwtUtil.extractUsername(eq(testuserToken))).thenReturn(TEST_USERNAME);
        when(jwtUtil.extractUsername(eq(otheruserToken))).thenReturn(OTHER_USERNAME);

        // For any other token, return null username (invalid)
        when(jwtUtil.extractUsername(anyString())).thenAnswer(invocation -> {
            String token = invocation.getArgument(0);
            if (token.equals(testuserToken)) return TEST_USERNAME;
            if (token.equals(otheruserToken)) return OTHER_USERNAME;
            return null;
        });

        // Mock AuthService to extract username from token
        when(authService.getCurrentUsername(anyString())).thenAnswer(invocation -> {
            String authHeader = invocation.getArgument(0);
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7); // Remove "Bearer "
                if (jwtUtil.validate(token)) {
                    return jwtUtil.extractUsername(token);
                }
            }
            return null;
        });

        // Initialize in-memory storage for repository mocks
        when(cardRepository.save(any(Card.class))).thenAnswer(invocation -> {
            Card card = invocation.getArgument(0);
            if (card.getId() == null) {
                card.setId(generateId());
            }
            return card;
        });

        when(cardRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            // Simulate finding card by ID in memory
            // This is simplified - in real test we'd maintain a map
            return Optional.ofNullable(new Card());
        });

        when(cardRepository.findByIdAndUsername(anyLong(), anyString())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            String username = invocation.getArgument(1);
            Card card = new Card();
            card.setId(id);
            card.setUsername(username);
            // Simulate checking if card belongs to user
            if (card != null && Objects.equals(card.getUsername(), username)) {
                return Optional.of(card);
            }
            return Optional.empty();
        });

        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> {
            Transaction transaction = invocation.getArgument(0);
            if (transaction.getId() == null) {
                transaction.setId(generateId());
            }
            return transaction;
        });

        when(transactionRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return Optional.ofNullable(new Transaction());
        });

        when(transactionRepository.findByCardId(anyLong())).thenAnswer(invocation -> {
            Long cardId = invocation.getArgument(0);
            // Return empty list for simplicity - can be customized in tests
            return List.of();
        });

        // Mock IdempotencyService
        when(idempotencyService.isProcessed(anyString())).thenReturn(false);
        when(idempotencyService.getResultId(anyString())).thenReturn(null);
        doNothing().when(idempotencyService).markAsProcessed(anyString(), anyString());
    }

    private Long generateId() {
        // Simple ID generator for test purposes
        return System.currentTimeMillis() % 10000;
    }

    private String createAuthHeader(String username) {
        String token = Jwts.builder()
                .setSubject(username)
                .signWith(Keys.hmacShaKeyFor(TEST_SECRET.getBytes()))
                .compact();
        return "Bearer " + token;
    }

    /**
     * Test suite for Card Creation
     */
    @Nested
    @DisplayName("Card Creation Tests")
    class CardCreationTests {

        @Test
        @DisplayName("Should create card with valid initial balance")
        void testCreateCardValidBalance() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal initialBalance = new BigDecimal("100.00");

            // Act
            Card card = cardService.createCard(authHeader, "Test User", initialBalance);

            // Assert
            assertNotNull(card);
            assertEquals("Test User", card.getCardholderName());
            assertEquals(initialBalance, card.getBalance());
            assertEquals(CardStatus.ACTIVE, card.getStatus());
            assertEquals(TEST_USERNAME, card.getUsername());
        }

        @Test
        @DisplayName("Should create card with zero initial balance")
        void testCreateCardZeroBalance() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal initialBalance = BigDecimal.ZERO;

            // Act
            Card card = cardService.createCard(authHeader, "Test User", initialBalance);

            // Assert
            assertNotNull(card);
            assertEquals(BigDecimal.ZERO, card.getBalance());
            assertEquals(CardStatus.ACTIVE, card.getStatus());
        }

        @Test
        @DisplayName("Should throw exception when creating card with negative balance")
        void testCreateCardNegativeBalance() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal initialBalance = new BigDecimal("-10.00");

            // Act & Assert
            assertThrows(IllegalArgumentException.class, () -> {
                cardService.createCard(authHeader, "Test User", initialBalance);
            });
        }

        @Test
        @DisplayName("Should throw exception when creating card with null auth header")
        void testCreateCardNullAuthHeader() {
            // Act & Assert
            assertThrows(IllegalStateException.class, () -> {
                cardService.createCard(null, "Test User", new BigDecimal("100.00"));
            });
        }

        @Test
        @DisplayName("Should throw exception when creating card with invalid token")
        void testCreateCardInvalidToken() {
            // Arrange
            String authHeader = "Bearer invalidtoken";
            when(authService.getCurrentUsername(authHeader)).thenReturn(null);

            // Act & Assert
            assertThrows(IllegalStateException.class, () -> {
                cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
            });
        }
    }

    /**
     * Test suite for Spending from Card
     */
    @Nested
    @DisplayName("Spend from Card Tests")
    class SpendFromCardTests {

        @BeforeEach
        void setUpSpendTests() {
            // Set up a test card for spending tests
            String authHeader = createAuthHeader(TEST_USERNAME);
            Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
            testCardId = card.getId();

            // Mock repository to return our test card
            when(cardRepository.findByIdAndUsername(testCardId, TEST_USERNAME))
                    .thenReturn(Optional.of(card));
        }

        @Test
        @DisplayName("Should successfully spend from card with sufficient funds")
        void testSpendFromCardSufficientFunds() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = new BigDecimal("30.00");
            String idempotencyKey = "spend-1";

            // Act
            Transaction transaction = cardService.spendFromCard(authHeader, testCardId, amount, idempotencyKey);

            // Assert
            assertNotNull(transaction);
            assertEquals(testCardId, transaction.getCardId());
            assertEquals(TransactionType.SPEND, transaction.getType());
            assertEquals(amount, transaction.getAmount());
            assertEquals(TransactionStatus.SUCCESSFUL, transaction.getStatus());

            // Verify card balance decreased
            Card updatedCard = cardService.getCardDetails(authHeader, testCardId);
            assertEquals(new BigDecimal("70.00"), updatedCard.getBalance());
        }

        @Test
        @DisplayName("Should respect idempotency for spend operations")
        void testSpendFromCardIdempotency() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = new BigDecimal("20.00");
            String idempotencyKey = "idempotent-key";

            // Act - First request
            Transaction firstTransaction = cardService.spendFromCard(authHeader, testCardId, amount, idempotencyKey);

            // Act - Second request with same idempotency key
            Transaction secondTransaction = cardService.spendFromCard(authHeader, testCardId, amount, idempotencyKey);

            // Assert
            assertNotNull(firstTransaction);
            assertNotNull(secondTransaction);
            assertEquals(firstTransaction.getId(), secondTransaction.getId());
            assertEquals(firstTransaction.getAmount(), secondTransaction.getAmount());
            assertEquals(firstTransaction.getStatus(), secondTransaction.getStatus());

            // Verify card balance only decreased once
            Card card = cardService.getCardDetails(authHeader, testCardId);
            assertEquals(new BigDecimal("80.00"), card.getBalance()); // 100 - 20 = 80
        }

        @Test
        @DisplayName("Should decline transaction when insufficient funds")
        void testSpendFromCardInsufficientFunds() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = new BigDecimal("150.00"); // More than balance
            String idempotencyKey = "spend-2";

            // Act
            Transaction transaction = cardService.spendFromCard(authHeader, testCardId, amount, idempotencyKey);

            // Assert
            assertNotNull(transaction);
            assertEquals(testCardId, transaction.getCardId());
            assertEquals(TransactionType.SPEND, transaction.getType());
            assertEquals(amount, transaction.getAmount());
            assertEquals(TransactionStatus.DECLINED, transaction.getStatus());

            // Verify card balance unchanged
            Card updatedCard = cardService.getCardDetails(authHeader, testCardId);
            assertEquals(new BigDecimal("100.00"), updatedCard.getBalance());
        }

        @Test
        @DisplayName("Should throw exception when spending negative amount")
        void testSpendFromCardNegativeAmount() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = new BigDecimal("-10.00");
            String idempotencyKey = "spend-negative";

            // Act & Assert
            assertThrows(IllegalArgumentException.class, () -> {
                cardService.spendFromCard(authHeader, testCardId, amount, idempotencyKey);
            });
        }

        @Test
        @DisplayName("Should throw exception when spending zero amount")
        void testSpendFromCardZeroAmount() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = BigDecimal.ZERO;
            String idempotencyKey = "spend-zero";

            // Act & Assert
            assertThrows(IllegalArgumentException.class, () -> {
                cardService.spendFromCard(authHeader, testCardId, amount, idempotencyKey);
            });
        }

        @Test
        @DisplayName("Should throw exception when trying to spend from blocked card")
        void testSpendFromCardBlocked() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Block the card first
            cardService.blockCard(authHeader, testCardId);

            // Try to spend
            assertThrows(IllegalStateException.class, () -> {
                cardService.spendFromCard(authHeader, testCardId, new BigDecimal("10.00"), "spend-blocked");
            });
        }

        @Test
        @DisplayName("Should throw exception when trying to spend from card of another user")
        void testSpendFromCardWrongUser() {
            // Arrange
            String authHeader = createAuthHeader(OTHER_USERNAME); // Different user

            // Act & Assert
            assertThrows(IllegalArgumentException.class, () -> {
                cardService.spendFromCard(authHeader, testCardId, new BigDecimal("10.00"), "spend-wrong-user");
            });
        }
    }

    /**
     * Test suite for Topping Up Card
     */
    @Nested
    @DisplayName("Top Up Card Tests")
    class TopUpCardTests {

        @BeforeEach
        void setUpTopUpTests() {
            // Set up a test card for top up tests
            String authHeader = createAuthHeader(TEST_USERNAME);
            Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("50.00"));
            testCardId = card.getId();

            // Mock repository to return our test card
            when(cardRepository.findByIdAndUsername(testCardId, TEST_USERNAME))
                    .thenReturn(Optional.of(card));
        }

        @Test
        @DisplayName("Should successfully top up card")
        void testTopUpCardSuccess() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = new BigDecimal("50.00");
            String idempotencyKey = "topup-1";

            // Act
            Transaction transaction = cardService.topUpCard(authHeader, testCardId, amount, idempotencyKey);

            // Assert
            assertNotNull(transaction);
            assertEquals(testCardId, transaction.getCardId());
            assertEquals(TransactionType.TOP_UP, transaction.getType());
            assertEquals(amount, transaction.getAmount());
            assertEquals(TransactionStatus.SUCCESSFUL, transaction.getStatus());

            // Verify card balance increased
            Card updatedCard = cardService.getCardDetails(authHeader, testCardId);
            assertEquals(new BigDecimal("100.00"), updatedCard.getBalance()); // 50 + 50 = 100
        }

        @Test
        @DisplayName("Should respect idempotency for top up operations")
        void testTopUpCardIdempotency() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = new BigDecimal("25.00");
            String idempotencyKey = "topup-idempotent-key";

            // Act - First request
            Transaction firstTransaction = cardService.topUpCard(authHeader, testCardId, amount, idempotencyKey);

            // Act - Second request with same idempotency key
            Transaction secondTransaction = cardService.topUpCard(authHeader, testCardId, amount, idempotencyKey);

            // Assert
            assertNotNull(firstTransaction);
            assertNotNull(secondTransaction);
            assertEquals(firstTransaction.getId(), secondTransaction.getId());
            assertEquals(firstTransaction.getAmount(), secondTransaction.getAmount());
            assertEquals(firstTransaction.getStatus(), secondTransaction.getStatus());

            // Verify card balance only increased once
            Card card = cardService.getCardDetails(authHeader, testCardId);
            assertEquals(new BigDecimal("75.00"), card.getBalance()); // 50 + 25 = 75
        }

        @Test
        @DisplayName("Should throw exception when topping up negative amount")
        void testTopUpCardNegativeAmount() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = new BigDecimal("-10.00");
            String idempotencyKey = "topup-negative";

            // Act & Assert
            assertThrows(IllegalArgumentException.class, () -> {
                cardService.topUpCard(authHeader, testCardId, amount, idempotencyKey);
            });
        }

        @Test
        @DisplayName("Should throw exception when topping up zero amount")
        void testTopUpCardZeroAmount() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            BigDecimal amount = BigDecimal.ZERO;
            String idempotencyKey = "topup-zero";

            // Act & Assert
            assertThrows(IllegalArgumentException.class, () -> {
                cardService.topUpCard(authHeader, testCardId, amount, idempotencyKey);
            });
        }

        @Test
        @DisplayName("Should throw exception when trying to top up blocked card")
        void testTopUpCardBlocked() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Block the card first
            cardService.blockCard(authHeader, testCardId);

            // Try to top up
            assertThrows(IllegalStateException.class, () -> {
                cardService.topUpCard(authHeader, testCardId, new BigDecimal("10.00"), "topup-blocked");
            });
        }
    }

    /**
     * Test suite for Card Status Management
     */
    @Nested
    @DisplayName("Card Status Management Tests")
    class CardStatusTests {

        @BeforeEach
        void setUpStatusTests() {
            // Set up a test card for status tests
            String authHeader = createAuthHeader(TEST_USERNAME);
            Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
            testCardId = card.getId();

            // Mock repository to return our test card
            when(cardRepository.findByIdAndUsername(testCardId, TEST_USERNAME))
                    .thenReturn(Optional.of(card));
        }

        @Test
        @DisplayName("Should successfully block card")
        void testBlockCardSuccess() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Act
            Card blockedCard = cardService.blockCard(authHeader, testCardId);

            // Assert
            assertNotNull(blockedCard);
            assertEquals(CardStatus.BLOCKED, blockedCard.getStatus());
        }

        @Test
        @DisplayName("Should successfully close card")
        void testCloseCardSuccess() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Act
            Card closedCard = cardService.closeCard(authHeader, testCardId);

            // Assert
            assertNotNull(closedCard);
            assertEquals(CardStatus.CLOSED, closedCard.getStatus());
        }

        @Test
        @DisplayName("Should prevent spending from blocked card")
        void testPreventSpendFromBlockedCard() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Block the card
            cardService.blockCard(authHeader, testCardId);

            // Act & Assert
            assertThrows(IllegalStateException.class, () -> {
                cardService.spendFromCard(authHeader, testCardId, new BigDecimal("10.00"), "spend-blocked");
            });
        }

        @Test
        @DisplayName("Should prevent topping up blocked card")
        void testPreventTopUpBlockedCard() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Block the card
            cardService.blockCard(authHeader, testCardId);

            // Act & Assert
            assertThrows(IllegalStateException.class, () -> {
                cardService.topUpCard(authHeader, testCardId, new BigDecimal("10.00"), "topup-blocked");
            });
        }

        @Test
        @DisplayName("Should prevent spending from closed card")
        void testPreventSpendFromClosedCard() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Close the card
            cardService.closeCard(authHeader, testCardId);

            // Act & Assert
            assertThrows(IllegalStateException.class, () -> {
                cardService.spendFromCard(authHeader, testCardId, new BigDecimal("10.00"), "spend-closed");
            });
        }

        @Test
        @DisplayName("Should prevent topping up closed card")
        void testPreventTopUpClosedCard() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Close the card
            cardService.closeCard(authHeader, testCardId);

            // Act & Assert
            assertThrows(IllegalStateException.class, () -> {
                cardService.topUpCard(authHeader, testCardId, new BigDecimal("10.00"), "topup-closed");
            });
        }
    }

    /**
     * Test suite for Transaction History
     */
    @Nested
    @DisplayName("Transaction History Tests")
    class TransactionHistoryTests {

        @BeforeEach
        void setUpHistoryTests() {
            // Set up a test card for history tests
            String authHeader = createAuthHeader(TEST_USERNAME);
            Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
            testCardId = card.getId();

            // Mock repository to return our test card
            when(cardRepository.findByIdAndUsername(testCardId, TEST_USERNAME))
                    .thenReturn(Optional.of(card));

            // Mock transaction repository to return some test transactions
            Transaction spendTxn = new Transaction();
            spendTxn.setId(1L);
            spendTxn.setCardId(testCardId);
            spendTxn.setAmount(new BigDecimal("20.00"));
            spendTxn.setType(TransactionType.SPEND);
            spendTxn.setStatus(TransactionStatus.SUCCESSFUL);

            Transaction topupTxn = new Transaction();
            topupTxn.setId(2L);
            topupTxn.setCardId(testCardId);
            topupTxn.setAmount(new BigDecimal("30.00"));
            topupTxn.setType(TransactionType.TOP_UP);
            topupTxn.setStatus(TransactionStatus.SUCCESSFUL);

            when(transactionRepository.findByCardId(testCardId))
                    .thenReturn(List.of(spendTxn, topupTxn));
        }

        @Test
        @DisplayName("Should return transaction history for card")
        void testGetTransactionHistory() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Act
            List<Transaction> transactions = cardService.getTransactionHistory(authHeader, testCardId);

            // Assert
            assertNotNull(transactions);
            assertEquals(2, transactions.size());

            // Verify we have both spend and top-up transactions
            long spendCount = transactions.stream()
                    .filter(t -> t.getType() == TransactionType.SPEND)
                    .count();
            long topUpCount = transactions.stream()
                    .filter(t -> t.getType() == TransactionType.TOP_UP)
                    .count();

            assertEquals(1, spendCount);
            assertEquals(1, topUpCount);
        }

        @Test
        @DisplayName("Should return empty list when no transactions exist")
        void testGetTransactionHistoryEmpty() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);

            // Mock transaction repository to return empty list
            when(transactionRepository.findByCardId(testCardId))
                    .thenReturn(List.of());

            // Act
            List<Transaction> transactions = cardService.getTransactionHistory(authHeader, testCardId);

            // Assert
            assertNotNull(transactions);
            assertTrue(transactions.isEmpty());
        }

        @Test
        @DisplayName("Should throw exception when getting history for card of another user")
        void testGetTransactionHistoryWrongUser() {
            // Arrange
            String authHeader = createAuthHeader(OTHER_USERNAME); // Different user

            // Act & Assert
            assertThrows(IllegalArgumentException.class, () -> {
                cardService.getTransactionHistory(authHeader, testCardId);
            });
        }
    }

    /**
     * Test suite for Edge Cases and Error Conditions
     */
    @Nested
    @DisplayName("Edge Case Tests")
    class EdgeCaseTests {

        @Test
        @DisplayName("Should handle spending exact balance (results in zero)")
        void testSpendExactBalance() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
            Long cardId = card.getId();

            // Mock repository to return our test card
            when(cardRepository.findByIdAndUsername(cardId, TEST_USERNAME))
                    .thenReturn(Optional.of(card));

            // Act
            Transaction transaction = cardService.spendFromCard(authHeader, cardId,
                    new BigDecimal("100.00"), "spend-exact");

            // Assert
            assertNotNull(transaction);
            assertEquals(TransactionStatus.SUCCESSFUL, transaction.getStatus());
            assertEquals(new BigDecimal("100.00"), transaction.getAmount());

            // Verify card balance is now zero
            Card updatedCard = cardService.getCardDetails(authHeader, cardId);
            assertEquals(BigDecimal.ZERO, updatedCard.getBalance());
        }

        @Test
        @DisplayName("Should handle multiple transactions correctly")
        void testMultipleTransactions() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
            Long cardId = card.getId();

            // Mock repository to return our test card
            when(cardRepository.findByIdAndUsername(cardId, TEST_USERNAME))
                    .thenReturn(Optional.of(card));

            // Act - Perform series of transactions
            cardService.spendFromCard(authHeader, cardId, new BigDecimal("25.00"), "txn-1"); // 100 - 25 = 75
            cardService.topUpCard(authHeader, cardId, new BigDecimal("50.00"), "txn-2");     // 75 + 50 = 125
            cardService.spendFromCard(authHeader, cardId, new BigDecimal("30.00"), "txn-3"); // 125 - 30 = 95

            // Assert
            Card finalCard = cardService.getCardDetails(authHeader, cardId);
            assertEquals(new BigDecimal("95.00"), finalCard.getBalance());

            // Verify transaction history
            List<Transaction> transactions = cardService.getTransactionHistory(authHeader, cardId);
            // Initial top-up (from card creation) + 3 transactions = 4 transactions
            assertEquals(4, transactions.size());

            // Count by type
            long spendCount = transactions.stream()
                    .filter(t -> t.getType() == TransactionType.SPEND)
                    .count();
            long topUpCount = transactions.stream()
                    .filter(t -> t.getType() == TransactionType.TOP_UP)
                    .count();

            assertEquals(2, spendCount); // Two spend transactions
            assertEquals(2, topUpCount); // Initial + manual top-up
        }

        @Test
        @DisplayName("Should handle concurrent-like idempotency scenarios")
        void testIdempotencyWithDifferentAmounts() {
            // Arrange
            String authHeader = createAuthHeader(TEST_USERNAME);
            Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
            Long cardId = card.getId();

            // Mock repository to return our test card
            when(cardRepository.findByIdAndUsername(cardId, TEST_USERNAME))
                    .thenReturn(Optional.of(card));

            // Act - First request with idempotency key
            Transaction firstTransaction = cardService.spendFromCard(authHeader, cardId,
                    new BigDecimal("20.00"), "idempotent-key");

            // Act - Second request with same idempotency key but different amount
            Transaction secondTransaction = cardService.spendFromCard(authHeader, cardId,
                    new BigDecimal("30.00"), "idempotent-key");

            // Assert
            assertNotNull(firstTransaction);
            assertNotNull(secondTransaction);
            // Should be the same transaction due to idempotency
            assertEquals(firstTransaction.getId(), secondTransaction.getId());
            assertEquals(firstTransaction.getAmount(), secondTransaction.getAmount());

            // Card balance should only be decreased by the first amount
            Card updatedCard = cardService.getCardDetails(authHeader, cardId);
            assertEquals(new BigDecimal("80.00"), updatedCard.getBalance()); // 100 - 20 = 80
        }
    }
}