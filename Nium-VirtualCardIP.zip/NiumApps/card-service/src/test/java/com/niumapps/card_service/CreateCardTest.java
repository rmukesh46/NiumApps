package com.niumapps.card_service;

import com.niumapps.card_service.model.Card;
import com.niumapps.card_service.model.Transaction;
import com.niumapps.card_service.model.TransactionStatus;
import com.niumapps.card_service.repository.CardRepository;
import com.niumapps.card_service.repository.TransactionRepository;
import com.niumapps.card_service.service.CardService;
import com.niumapps.card_service.service.IdempotencyService;
import com.niumapps.card_service.service.AuthService;
import com.niumapps.card_service.util.JwtUtil;
import com.niumapps.card_service.client.UserDto;
import com.niumapps.card_service.client.UserServiceClient;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CreateCardTest {

    @InjectMocks
    private CardService cardService;

    @Mock
    private UserServiceClient userServiceClient;

    @Mock
    private AuthService authService;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private CardRepository cardRepository;

    @Mock
    private TransactionRepository transactionRepository;

    private Long testCardId;

    private String createValidToken(String username) {
        // This uses the same secret as in JwtUtil
        String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
        return Jwts.builder()
                .setSubject(username)
                .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .compact();
    }

    @BeforeEach
    void setUp() {
        // Mock the dependencies that are actually called
        when(authService.getCurrentUsername(anyString())).thenReturn("testuser");
        when(cardRepository.save(any(Card.class))).thenAnswer(invocation -> {
            Card card = invocation.getArgument(0);
            if (card.getId() == null) {
                card.setId(1L);
            }
            return card;
        });
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> {
            Transaction transaction = invocation.getArgument(0);
            if (transaction.getId() == null) {
                transaction.setId(1L);
            }
            return transaction;
        });

        // Create a test card before each test
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
        testCardId = card.getId();
    }

    @Test
    void testCreateCard() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        Card card = cardService.createCard(authHeader, "John Doe", new BigDecimal("50.00"));

        assertNotNull(card.getId());
        assertEquals("John Doe", card.getCardholderName());
        assertEquals(new BigDecimal("50.00"), card.getBalance());
        assertEquals(com.niumapps.card_service.model.CardStatus.ACTIVE, card.getStatus());
        assertEquals("testuser", card.getUsername());
    }
}