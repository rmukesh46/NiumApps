package com.niumapps.card_service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;

public class JwtTest {
    public static void main(String[] args) {
        try {
            String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
            SecretKey key = Keys.hmacShaKeyFor(secret.getBytes());

            String jwt = Jwts.builder()
                    .setSubject("testuser")
                    .signWith(key)
                    .compact();

            System.out.println("JWT: " + jwt);

            // Parse it back
            String username = Jwts.parser()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJwt(jwt)
                    .getBody()
                    .getSubject();

            System.out.println("Username: " + username);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}