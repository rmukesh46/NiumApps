package com.niumapps.card_service;

import com.niumapps.card_service.model.Card;
import com.niumapps.card_service.model.CardStatus;
import com.niumapps.card_service.model.Transaction;
import com.niumapps.card_service.model.TransactionStatus;
import com.niumapps.card_service.model.TransactionType;
import com.niumapps.card_service.repository.CardRepository;
import com.niumapps.card_service.repository.TransactionRepository;
import com.niumapps.card_service.service.CardService;
import com.niumapps.card_service.service.IdempotencyService;
import com.niumapps.card_service.service.AuthService;
import com.niumapps.card_service.util.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CardServiceEdgeCaseTest {

    @InjectMocks
    private CardService cardService;

    @Mock
    private CardRepository cardRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private IdempotencyService idempotencyService;

    @Mock
    private AuthService authService;

    @Mock
    private JwtUtil jwtUtil;

    private Long testCardId;

    private String createValidToken(String username) {
        // This uses the same secret as in JwtUtil
        String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
        return Jwts.builder()
                .setSubject(username)
                .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .compact();
    }

    @BeforeEach
    void setUp() {
        // Mock the auth service to return the username from the token
        when(authService.getCurrentUsername(anyString())).thenAnswer(invocation -> {
            String authHeader = invocation.getArgument(0);
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7); // Remove "Bearer "
                if (jwtUtil.validate(token)) {
                    return jwtUtil.extractUsername(token);
                }
            }
            return null;
        });

        // Mock the JwtUtil to validate tokens and extract usernames
        when(jwtUtil.validate(anyString())).thenReturn(true);
        when(jwtUtil.extractUsername(anyString())).thenAnswer(invocation -> {
            String token = invocation.getArgument(0);
            String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
            try {
                Claims claims = Jwts.parser()
                        .verifyWith(Keys.hmacShaKeyFor(secret.getBytes()))
                        .build()
                        .parseSignedClaims(token)
                        .getPayload();
                return claims.getSubject();
            } catch (Exception e) {
                return null;
            }
        });

        // Mock repositories with in-memory storage
        when(cardRepository.save(any(Card.class))).thenAnswer(invocation -> {
            Card card = invocation.getArgument(0);
            if (card.getId() == null) {
                card.setId(1L);
            }
            return card;
        });
        when(cardRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return java.util.Optional.ofNullable(new Card());
        });
        when(cardRepository.findByIdAndUsername(anyLong(), anyString())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            String username = invocation.getArgument(1);
            Card card = new Card();
            card.setId(id);
            card.setUsername(username);
            if (card != null && Objects.equals(card.getUsername(), username)) {
                return java.util.Optional.of(card);
            }
            return java.util.Optional.empty();
        });
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> {
            Transaction transaction = invocation.getArgument(0);
            if (transaction.getId() == null) {
                transaction.setId(1L);
            }
            return transaction;
        });
        when(transactionRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return java.util.Optional.ofNullable(new Transaction());
        });
        when(transactionRepository.findByCardId(anyLong())).thenAnswer(invocation -> {
            Long cardId = invocation.getArgument(0);
            return java.util.List.of(new Transaction());
        });

        // Create a test card before each test
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;
        Card card = cardService.createCard(authHeader, "Test User", new BigDecimal("100.00"));
        testCardId = card.getId();
    }

    @Test
    void testSpendExactBalance() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Spend exactly the current balance
        Transaction transaction = cardService.spendFromCard(authHeader, testCardId, new BigDecimal("100.00"), "spend-exact");

        assertNotNull(transaction);
        assertEquals(TransactionStatus.SUCCESSFUL, transaction.getStatus());
        assertEquals(new BigDecimal("100.00"), transaction.getAmount());

        // Verify card balance is now zero
        Card updatedCard = cardService.getCardDetails(authHeader, testCardId);
        assertEquals(BigDecimal.ZERO, updatedCard.getBalance());
    }

    @Test
    void testTopUpZeroAmount() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Try to top up with zero amount - should fail
        assertThrows(IllegalArgumentException.class, () -> {
            cardService.topUpCard(authHeader, testCardId, BigDecimal.ZERO, "topup-zero");
        });
    }

    @Test
    void testSpendZeroAmount() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Try to spend zero amount - should fail
        assertThrows(IllegalArgumentException.class, () -> {
            cardService.spendFromCard(authHeader, testCardId, BigDecimal.ZERO, "spend-zero");
        });
    }

    @Test
    void testGetTransactionHistoryEmpty() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Mock transaction repository to return empty list
        when(transactionRepository.findByCardId(anyLong())).thenReturn(java.util.List.of());

        List<Transaction> transactions = cardService.getTransactionHistory(authHeader, testCardId);

        assertNotNull(transactions);
        assertTrue(transactions.isEmpty());
    }

    @Test
    void testGetCardDetailsNotFound() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Mock card repository to return empty optional
        when(cardRepository.findByIdAndUsername(anyLong(), anyString())).thenReturn(java.util.Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> {
            cardService.getCardDetails(authHeader, testCardId);
        });
    }

    @Test
    void testBlockCardThenSpend() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Block the card
        cardService.blockCard(authHeader, testCardId);

        // Try to spend from blocked card - should throw exception
        assertThrows(IllegalStateException.class, () -> {
            cardService.spendFromCard(authHeader, testCardId, new BigDecimal("10.00"), "spend-blocked");
        });
    }

    @Test
    void testCloseCardThenSpend() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Close the card
        cardService.closeCard(authHeader, testCardId);

        // Try to spend from closed card - should throw exception
        assertThrows(IllegalStateException.class, () -> {
            cardService.spendFromCard(authHeader, testCardId, new BigDecimal("10.00"), "spend-closed");
        });
    }

    @Test
    void testIdempotencyWithDifferentAmounts() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // First request with idempotency key
        Transaction firstTransaction = cardService.spendFromCard(authHeader, testCardId, new BigDecimal("20.00"), "idempotent-key");

        // Second request with same idempotency key but different amount - should return first transaction
        Transaction secondTransaction = cardService.spendFromCard(authHeader, testCardId, new BigDecimal("30.00"), "idempotent-key");

        // Should be the same transaction (idempotency key takes precedence)
        assertEquals(firstTransaction.getId(), secondTransaction.getId());
        assertEquals(firstTransaction.getAmount(), secondTransaction.getAmount());

        // Card balance should only be decreased by the first amount
        Card card = cardService.getCardDetails(authHeader, testCardId);
        assertEquals(new BigDecimal("80.00"), card.getBalance()); // Started with 100, spent 20
    }

    @Test
    void testConcurrentLikeScenario() {
        String token = createValidToken("testuser");
        String authHeader = "Bearer " + token;

        // Perform multiple transactions
        cardService.spendFromCard(authHeader, testCardId, new BigDecimal("10.00"), "txn-1");
        cardService.topUpCard(authHeader, testCardId, new BigDecimal("25.00"), "txn-2");
        cardService.spendFromCard(authHeader, testCardId, new BigDecimal("5.00"), "txn-3");

        // Verify final balance
        Card card = cardService.getCardDetails(authHeader, testCardId);
        // Started with 100, spent 10, topped up 25, spent 5 = 110
        assertEquals(new BigDecimal("110.00"), card.getBalance());

        // Verify transaction history
        List<Transaction> transactions = cardService.getTransactionHistory(authHeader, testCardId);
        // Initial top-up (from card creation) + 3 transactions = 4 transactions
        assertEquals(4, transactions.size());

        // Count by type
        long spendCount = transactions.stream()
                .filter(t -> t.getType() == TransactionType.SPEND)
                .count();
        long topUpCount = transactions.stream()
                .filter(t -> t.getType() == TransactionType.TOP_UP)
                .count();

        assertEquals(2, spendCount); // Two spend transactions
        assertEquals(2, topUpCount); // Initial + manual top-up
    }
}