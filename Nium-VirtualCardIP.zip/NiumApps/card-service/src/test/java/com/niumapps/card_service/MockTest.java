package com.niumapps.card_service;

import com.niumapps.card_service.service.AuthService;
import com.niumapps.card_service.util.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.crypto.SecretKey;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MockTest {

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private AuthService authService;

    @Test
    void testJwtUtilMock() {
        // Arrange
        String secret = "MyVeryLongSecretKeyForJwtAuthentication123456789";
        String token = Jwts.builder()
                .subject("testuser")
                .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .compact();

        // Act
        when(jwtUtil.extractUsername(token)).thenReturn("testuser");
        String result = jwtUtil.extractUsername(token);

        // Assert
        assertEquals("testuser", result);
        verify(jwtUtil).extractUsername(token);
    }

    @Test
    void testAuthServiceMock() {
        // Arrange
        when(authService.getCurrentUsername("Bearer validtoken")).thenReturn("testuser");

        // Act
        String result = authService.getCurrentUsername("Bearer validtoken");

        // Assert
        assertEquals("testuser", result);
        verify(authService).getCurrentUsername("Bearer validtoken");
    }
}