# Nium Apps Payment System Architecture

## Overview
This is a microservices-based payment system consisting of three main services:
1. **User Service** - Handles user authentication and management
2. **Card Service** - Manages payment cards and financial transactions
3. **API Gateway** - Routes requests and handles cross-cutting concerns like authentication

## Services

### User Service
Responsible for user registration, authentication, and session management.

**Key Features:**
- User registration with password hashing (BCrypt)
- JWT-based authentication
- Login/logout endpoints
- User profile management

**Endpoints:**
- `POST /auth/user/register` - Register new user
- `GET /auth/user/login` - Authenticate user and receive JWT token
- `POST /auth/user/logout` - Logout and clear session
- `GET /auth/user/` - Get all users
- `GET /auth/user/{username}` - Get user by username

**Security:**
- Passwords are hashed using BCrypt before storage
- JWT tokens are signed with a shared secret
- Tokens contain user username and role claims

### Card Service
Handles payment card operations and financial transactions.

**Key Features:**
- Card creation with initial balance
- Spending funds from cards (decreasing balance)
- Topping up cards (increasing balance)
- Card blocking and closing for security
- Transaction history tracking
- Idempotency protection for financial operations

**Key Concepts:**
- **Idempotency**: Financial operations use idempotency keys to prevent duplicate processing
- **Authentication**: All operations require valid JWT token in Authorization header
- **Authorization**: Users can only access their own cards
- **Transaction Safety**: All financial operations are transactional

**Card Statuses:**
- `ACTIVE`: Card can be used for transactions
- `BLOCKED`: Card temporarily disabled (no transactions allowed)
- `CLOSED`: Card permanently disabled

**Endpoints:**
- `POST /cards` - Create new card
- `GET /cards/{cardId}` - Get card details
- `POST /cards/{cardId}/spend` - Spend from card
- `POST /cards/{cardId}/topup` - Top up card
- `GET /cards/{cardId}/transactions` - Get transaction history
- `POST /cards/{cardId}/block` - Block card
- `POST /cards/{cardId}/close` - Close card

### API Gateway
Acts as the entry point for all client requests.

**Key Features:**
- Request routing to appropriate services
- JWT token validation
- Cookie-based token storage (httpOnly, secure)
- Automatic token refresh on login
- Token clearing on logout
- Path-based authentication exemptions

**Authentication Flow:**
1. Client sends request with JWT in Authorization header OR jwt_token cookie
2. Gateway validates token signature and expiration
3. If valid, request is forwarded to appropriate service
4. For login responses, gateway sets httpOnly cookie with JWT
5. For logout requests, gateway clears the jwt_token cookie

**Exempt Paths (no authentication required):**
- `/auth/user/login`
- `/auth/user/register`
- `/auth/user/logout`
- `/v3/api-docs`

## Security Considerations

### Token Management
- JWT tokens are stored in httpOnly cookies to prevent XSS attacks
- Tokens have 1-hour expiration
- Same secret key is shared across all services for token validation
- Authorization header takes precedence over cookie when both present

### Data Protection
- Passwords are hashed using BCrypt (work factor 10)
- Financial transactions use decimal precision (19,2) for accuracy
- All services validate user ownership before allowing card access
- Idempotency keys prevent duplicate financial transactions

### Communication
- Services communicate via REST over HTTP
- Internal service-to-service communication would typically use service discovery
- In this implementation, services are independent and don't call each other directly

## Database Schema

### Users Table
- id (PK, auto-increment)
- username (unique, not null)
- password (hashed, not null)

### Cards Table
- id (PK, auto-increment)
- cardholder_name (not null)
- balance (decimal 19,2, not null)
- status (enum: ACTIVE, BLOCKED, CLOSED, not null)
- username (not null, foreign key to users.username)
- created_at (timestamp, not null)

### Transactions Table
- id (PK, auto-increment)
- card_id (not null, foreign key to cards.id)
- type (enum: SPEND, TOP_UP, not null)
- amount (decimal 19,2, not null)
- status (enum: PENDING, SUCCESSFUL, DECLINED, not null)
- created_at (timestamp, not null)

## Installation and Setup
1. Ensure Java 21+ is installed
2. Configure application.properties for each service with appropriate database connections
3. Start User Service first (on port 8083)
4. Start Card Service second (on port 8081)
5. Start API Gateway last (on port 8080)
6. Access the system through the API Gateway at http://localhost:8080

## Testing
Each service includes comprehensive unit tests covering:
- Controllers
- Services
- Repositories
- Utility classes
- Edge cases and error conditions

Run tests with: `./gradlew test`